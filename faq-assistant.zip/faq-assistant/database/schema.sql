CREATE DATABASE IF NOT EXISTS faq_assistant;
USE  faq_assistant;

--------------------------------------------   TABLES  -----------------------------------------------------
-- Category Table
CREATE TABLE IF NOT EXISTS category (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL UNIQUE,
    Description VARCHAR(255),
    IsActive TINYINT DEFAULT 1,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- User Table
CREATE TABLE IF NOT EXISTS `user` (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    UserName VARCHAR(100) NOT NULL UNIQUE,
    Email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    IsActive TINYINT DEFAULT 1,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- FAQ Table
CREATE TABLE IF NOT EXISTS faq (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    Question TEXT NOT NULL,
    Answer TEXT,
    CategoryId BIGINT NOT NULL,
    IsActive TINYINT DEFAULT 1,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (CategoryId) REFERENCES category(Id),
    FOREIGN KEY (CreatedBy) REFERENCES user(Id),
    FOREIGN KEY (UpdatedBy) REFERENCES user(id)
);

-- Tag Table
CREATE TABLE IF NOT EXISTS tag (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL UNIQUE,
    IsActive TINYINT DEFAULT 1,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- FAQ_Tag Mapping Table
CREATE TABLE IF NOT EXISTS faq_tag (
    FaqTagId BIGINT AUTO_INCREMENT PRIMARY KEY,
    FaqId BIGINT NOT NULL,
    TagId BIGINT NOT NULL,
    IsActive TINYINT DEFAULT 1,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (FaqId) REFERENCES faq(Id) ON DELETE CASCADE,
    FOREIGN KEY (TagId) REFERENCES tag(Id) ON DELETE CASCADE
);

----------------------------------------------- DATA INSERTIONS ------------------------------------------------------------------

-- Category Data Insertion
-- category_data.sql
DROP TEMPORARY TABLE IF EXISTS tempCategory;

CREATE TEMPORARY TABLE tempCategory (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL UNIQUE,
    Description VARCHAR(255),
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempCategory
(Id, Name, Description, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1, 'Billing', 'Questions related to billing and payments', 1, NULL, NOW(), NOW()),
(2, 'Account Setup', 'Questions about creating and configuring accounts', 1, NULL, NOW(), NOW()),
(3, 'Technical', 'Technical troubleshooting and support', 1, NULL, NOW(), NOW()),
(4, 'Subscriptions', 'Subscription plans, upgrades and cancellations', 1, NULL, NOW(), NOW()),
(5, 'Integrations', 'API, webhooks and 3rd-party integrations', 1, NULL, NOW(), NOW()),
(6, 'Security', 'Account security, 2FA and permissions', 1, NULL, NOW(), NOW());

SET SQL_SAFE_UPDATES = 0;

UPDATE category c
JOIN tempCategory temp
  ON c.Id = temp.Id
SET
    c.Name = temp.Name,
    c.Description = temp.Description,
    c.CreatedBy = temp.CreatedBy,
    c.UpdatedBy = temp.UpdatedBy,
    c.CreatedAt = temp.CreatedAt,
    c.UpdatedAt = temp.UpdatedAt;

INSERT INTO category
(Id, Name, Description, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.Id,
    temp.Name,
    temp.Description,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempCategory temp
LEFT JOIN category c
    ON c.Id = temp.Id
WHERE c.Id IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempCategory;


-- User Data Insertion
DROP TEMPORARY TABLE IF EXISTS tempUser;

CREATE TEMPORARY TABLE tempUser (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    UserName VARCHAR(100) NOT NULL UNIQUE,
    Email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempUser
(Id, UserName, Email, password_hash, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1, 'admin', 'admin@example.com', '$2a$10$gTjVNY9mQxQWnV9Lz0qvEOPGAJ8i6j7lH.Hm3MX0Zn7E35V7Sbn6C', 1, NULL, NOW(), NOW()),
(2, 'alice', 'alice@example.com', '$2a$10$BVpK8u94G1sm4Gx0JjH4tO81OJE9vZrjvDX2vZ9fFnmL0NwVt0KWK', 1, NULL, NOW(), NOW()),
(3, 'bob', 'bob@example.com', '$2a$10$vDcksyzqpbJtOk6xTtbF2OXeOIVhQYZBXK2ST6uuc2bhJtHqdVxzu', 1, NULL, NOW(), NOW()),
(4, 'support', 'support@example.com', '$2a$10$abcdefghabcdefghabcdefghabcdefghabcdefghabcdefghabcdef', 1, NULL, NOW(), NOW());

SET SQL_SAFE_UPDATES = 0;

UPDATE `user` u
JOIN tempUser temp
  ON u.Id = temp.Id
SET
    u.UserName = temp.UserName,
    u.Email = temp.Email,
    u.password_hash = temp.password_hash,
    u.CreatedBy = temp.CreatedBy,
    u.UpdatedBy = temp.UpdatedBy,
    u.CreatedAt = temp.CreatedAt,
    u.UpdatedAt = temp.UpdatedAt;

INSERT INTO `user`
(Id, UserName, Email, password_hash, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.Id,
    temp.UserName,
    temp.Email,
    temp.password_hash,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempUser temp
LEFT JOIN `user` u
    ON u.Id = temp.Id
WHERE u.Id IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempUser;


-- FAQ Data Insertion
DROP TEMPORARY TABLE IF EXISTS tempFaq;

CREATE TEMPORARY TABLE tempFaq (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    Question TEXT NOT NULL,
    Answer TEXT,
    CategoryId BIGINT NOT NULL,
    IsActive TINYINT DEFAULT 1,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempFaq
(Id, Question, Answer, CategoryId, IsActive, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1,
 'How can I view my billing history?',
 'You can view your billing history from the Billing section under your account settings. Select the Billing tab and choose the date range to export invoices.',
 1, 1, 1, NULL, NOW(), NOW()),

(2,
 'How do I reset my account password?',
 'Click on “Forgot Password” on the login page and follow the instructions sent to your email. If you do not receive the email, check spam or contact support.',
 2, 1, 1, NULL, NOW(), NOW()),

(3,
 'Why is my application not loading?',
 'This issue is usually caused by network restrictions or a missing update. Try clearing your browser cache and ensure you are on the latest supported browser version.',
 3, 1, 1, NULL, NOW(), NOW()),

(4,
 'How do I cancel my subscription?',
 'To cancel, go to your Account > Subscription page, choose Cancel Plan, and confirm. Cancellation will stop future billing but your account remains active until the period ends.',
 4, 1, 1, NULL, NOW(), NOW()),

(5,
 'How do I get a refund for a charge?',
 'Refunds are processed on a case-by-case basis. Open a support ticket with your invoice number and we will review within 5–7 business days.',
 1, 1, 1, NULL, NOW(), NOW()),

(6,
 'How do I integrate with the API?',
 'Refer to our API docs at /docs/api. You will find request examples, auth headers, and SDK links. Use your API key under Account > API Keys.',
 5, 1, 1, NULL, NOW(), NOW()),

(7,
 'How can I enable two-factor authentication (2FA)?',
 'Enable 2FA via Account > Security. Install an authenticator app and scan the QR code. Keep your backup codes stored securely.',
 6, 1, 1, NULL, NOW(), NOW()),

(8,
 'Why is my mobile app crashing on startup?',
 'Ensure the mobile app is updated. If issue persists, reinstall the app, check permissions, and capture logs to share with support.',
 3, 1, 1, NULL, NOW(), NOW()),

(9,
 'How do webhooks work?',
 'Webhooks POST JSON payloads to your callback URL. Subscribe under Integrations > Webhooks and test deliverability from the dashboard.',
 5, 1, 1, NULL, NOW(), NOW()),

(10,
 'How do I change my billing email address?',
 'Update billing email at Account > Billing > Edit Contact. You will receive a verification email to confirm the change.',
 1, 1, 1, NULL, NOW(), NOW()),

(11,
 'How to improve API response performance?',
 'Use bulk endpoints where possible, paginate requests, and cache repeated queries. Also ensure your network latency is low and request concurrency is limited.',
 3, 1, 1, NULL, NOW(), NOW()),

(12,
 'What should I do if I suspect my account was compromised?',
 'Immediately change your password, enable 2FA, and contact support. We can temporarily lock your account and review recent activity.',
 6, 1, 1, NULL, NOW(), NOW());

SET SQL_SAFE_UPDATES = 0;

UPDATE faq f
JOIN tempFaq temp
    ON f.Id = temp.Id
SET
    f.Question = temp.Question,
    f.Answer = temp.Answer,
    f.CategoryId = temp.CategoryId,
    f.IsActive = temp.IsActive,
    f.CreatedBy = temp.CreatedBy,
    f.UpdatedBy = temp.UpdatedBy,
    f.CreatedAt = temp.CreatedAt,
    f.UpdatedAt = temp.UpdatedAt;

INSERT INTO faq
(Id, Question, Answer, CategoryId, IsActive, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.Id,
    temp.Question,
    temp.Answer,
    temp.CategoryId,
    temp.IsActive,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempFaq temp
LEFT JOIN faq f
    ON f.Id = temp.Id
WHERE f.Id IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempFaq;


-- Tag Data Insertion
DROP TEMPORARY TABLE IF EXISTS tempTag;

CREATE TEMPORARY TABLE tempTag (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL UNIQUE,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempTag
(Id, Name, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1, 'General', 1, NULL, NOW(), NOW()),
(2, 'Urgent', 1, NULL, NOW(), NOW()),
(3, 'Feature Request', 1, NULL, NOW(), NOW()),
(4, 'Bug', 1, NULL, NOW(), NOW()),
(5, 'How-To', 1, NULL, NOW(), NOW()),
(6, 'Subscription', 1, NULL, NOW(), NOW()),
(7, 'Refund', 1, NULL, NOW(), NOW()),
(8, 'Password', 1, NULL, NOW(), NOW()),
(9, 'Login', 1, NULL, NOW(), NOW()),
(10, 'Mobile', 1, NULL, NOW(), NOW()),
(11, 'API', 1, NULL, NOW(), NOW()),
(12, 'Integration', 1, NULL, NOW(), NOW()),
(13, 'Security', 1, NULL, NOW(), NOW()),
(14, 'Performance', 1, NULL, NOW(), NOW());

SET SQL_SAFE_UPDATES = 0;

UPDATE tag t
JOIN tempTag temp
  ON t.Id = temp.Id
SET
    t.Name = temp.Name,
    t.CreatedBy = temp.CreatedBy,
    t.UpdatedBy = temp.UpdatedBy,
    t.CreatedAt = temp.CreatedAt,
    t.UpdatedAt = temp.UpdatedAt;

INSERT INTO tag
(Id, Name, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.Id,
    temp.Name,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempTag temp
LEFT JOIN tag t
    ON t.Id = temp.Id
WHERE t.Id IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempTag;


-- FAQ_Tag Data Insertion
DROP TEMPORARY TABLE IF EXISTS tempFaqTag;

CREATE TEMPORARY TABLE tempFaqTag (
    FaqTagId BIGINT AUTO_INCREMENT PRIMARY KEY,
    FaqId BIGINT NOT NULL,
    TagId BIGINT NOT NULL,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempFaqTag
(FaqTagId, FaqId, TagId, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1, 1, 1, 1, NULL, NOW(), NOW()), -- FAQ 1 -> General
(2, 1, 8, 1, NULL, NOW(), NOW()), -- FAQ 1 -> Password (if relevant)
(3, 2, 8, 1, NULL, NOW(), NOW()), -- FAQ 2 -> Password
(4, 2, 9, 1, NULL, NOW(), NOW()), -- FAQ 2 -> Login
(5, 3, 4, 1, NULL, NOW(), NOW()), -- FAQ 3 -> Bug
(6, 4, 6, 1, NULL, NOW(), NOW()), -- FAQ 4 -> Subscription
(7, 5, 7, 1, NULL, NOW(), NOW()), -- FAQ 5 -> Refund
(8, 6, 11, 1, NULL, NOW(), NOW()), -- FAQ 6 -> API
(9, 6, 12, 1, NULL, NOW(), NOW()), -- FAQ 6 -> Integration
(10, 7, 13, 1, NULL, NOW(), NOW()), -- FAQ 7 -> Security
(11, 8, 10, 1, NULL, NOW(), NOW()), -- FAQ 8 -> Mobile
(12, 9, 12, 1, NULL, NOW(), NOW()), -- FAQ 9 -> Integration
(13, 10, 1, 1, NULL, NOW(), NOW()), -- FAQ 10 -> General
(14, 11, 14, 1, NULL, NOW(), NOW()), -- FAQ 11 -> Performance
(15, 12, 13, 1, NULL, NOW(), NOW()); -- FAQ 12 -> Security

SET SQL_SAFE_UPDATES = 0;

UPDATE faq_tag ft
JOIN tempFaqTag temp
    ON ft.FaqTagId = temp.FaqTagId
SET
    ft.FaqId = temp.FaqId,
    ft.TagId = temp.TagId,
    ft.CreatedBy = temp.CreatedBy,
    ft.UpdatedBy = temp.UpdatedBy,
    ft.CreatedAt = temp.CreatedAt,
    ft.UpdatedAt = temp.UpdatedAt;

INSERT INTO faq_tag
(FaqTagId, FaqId, TagId, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.FaqTagId,
    temp.FaqId,
    temp.TagId,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempFaqTag temp
LEFT JOIN faq_tag ft
    ON ft.FaqTagId = temp.FaqTagId
WHERE ft.FaqTagId IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempFaqTag;


----------------------------------------------------- STORED PROCEDURES --------------------------------------------------------

-- GET ALL FAQS
DROP PROCEDURE IF EXISTS sp_GetAllFaqs;
DELIMITER $$

CREATE PROCEDURE sp_GetAllFaqs(
    IN p_CategoryId BIGINT,
    IN p_Tag VARCHAR(100),
    IN p_Keyword VARCHAR(255),
    IN p_Page BIGINT,
    IN p_PageSize BIGINT
)
BEGIN
    DECLARE v_page BIGINT DEFAULT 1;
    DECLARE v_pageSize BIGINT DEFAULT 20;
    DECLARE offsetRows BIGINT;
    DECLARE v_tag VARCHAR(100);
    DECLARE v_keyword VARCHAR(255);

    -- Normalize search inputs: empty => NULL
    SET v_tag = NULLIF(TRIM(p_Tag), '');
    SET v_keyword = NULLIF(TRIM(p_Keyword), '');

    -- Normalize pagination inputs but do NOT force a LIMIT if p_PageSize <= 0
    SET v_page = IFNULL(NULLIF(p_Page, 0), 1);
    SET v_pageSize = IFNULL(NULLIF(p_PageSize, 0), 20);
    SET offsetRows = (v_page - 1) * v_pageSize;

    -- ===== Result set 1: paged or all FAQ rows =====
    IF p_PageSize IS NOT NULL AND p_PageSize > 0 THEN
        SELECT
            f.Id,
            f.Question,
            f.Answer,
            f.CategoryId,
            c.Name AS CategoryName,
            GROUP_CONCAT(DISTINCT t.Name ORDER BY t.Name SEPARATOR ', ') AS Tags,
            f.CreatedBy,
            f.UpdatedBy,
            f.CreatedAt,
            f.UpdatedAt
        FROM faq f
        JOIN category c ON c.Id = f.CategoryId AND c.IsActive = 1
        LEFT JOIN faq_tag ft ON ft.FaqId = f.Id AND ft.IsActive = 1
        LEFT JOIN tag t ON t.Id = ft.TagId AND t.IsActive = 1
        WHERE
            f.IsActive = 1
            AND (p_CategoryId IS NULL OR p_CategoryId = 0 OR f.CategoryId = p_CategoryId)
            AND (
                v_tag IS NULL OR EXISTS (
                    SELECT 1
                    FROM faq_tag ft2
                    JOIN tag t2 ON t2.Id = ft2.TagId
                    WHERE ft2.FaqId = f.Id
                      AND ft2.IsActive = 1
                      AND t2.IsActive = 1
                      AND t2.Name LIKE CONCAT('%', v_tag, '%')
                )
            )
            AND (
                v_keyword IS NULL
                OR f.Question LIKE CONCAT('%', v_keyword, '%')
                OR f.Answer LIKE CONCAT('%', v_keyword, '%')
            )
        GROUP BY f.Id
        ORDER BY f.CreatedAt DESC
        LIMIT v_pageSize OFFSET offsetRows;
    ELSE
        -- No pagination requested: return ALL matching rows
        SELECT
            f.Id,
            f.Question,
            f.Answer,
            f.CategoryId,
            c.Name AS CategoryName,
            GROUP_CONCAT(DISTINCT t.Name ORDER BY t.Name SEPARATOR ', ') AS Tags
        FROM faq f
        JOIN category c ON c.Id = f.CategoryId AND c.IsActive = 1
        LEFT JOIN faq_tag ft ON ft.FaqId = f.Id AND ft.IsActive = 1
        LEFT JOIN tag t ON t.Id = ft.TagId AND t.IsActive = 1
        WHERE
            f.IsActive = 1
            AND (p_CategoryId IS NULL OR p_CategoryId = 0 OR f.CategoryId = p_CategoryId)
            AND (
                v_tag IS NULL OR EXISTS (
                    SELECT 1
                    FROM faq_tag ft2
                    JOIN tag t2 ON t2.Id = ft2.TagId
                    WHERE ft2.FaqId = f.Id
                      AND ft2.IsActive = 1
                      AND t2.IsActive = 1
                      AND t2.Name LIKE CONCAT('%', v_tag, '%')
                )
            )
            AND (
                v_keyword IS NULL
                OR f.Question LIKE CONCAT('%', v_keyword, '%')
                OR f.Answer LIKE CONCAT('%', v_keyword, '%')
            )
        GROUP BY f.Id
        ORDER BY f.CreatedAt DESC;
    END IF;

    -- ===== Result set 2: total count =====
    SELECT COUNT(DISTINCT f2.Id) AS TotalCount
    FROM faq f2
    JOIN category c2 ON c2.Id = f2.CategoryId AND c2.IsActive = 1
    LEFT JOIN faq_tag ft3 ON ft3.FaqId = f2.Id AND ft3.IsActive = 1
    LEFT JOIN tag t3 ON t3.Id = ft3.TagId AND t3.IsActive = 1
    WHERE
        f2.IsActive = 1
        AND (p_CategoryId IS NULL OR p_CategoryId = 0 OR f2.CategoryId = p_CategoryId)
        AND (
            v_tag IS NULL OR EXISTS (
                SELECT 1
                FROM faq_tag ft4
                JOIN tag t4 ON t4.Id = ft4.TagId
                WHERE ft4.FaqId = f2.Id
                  AND ft4.IsActive = 1
                  AND t4.IsActive = 1
                  AND t4.Name LIKE CONCAT('%', v_tag, '%')
            )
        )
        AND (
            v_keyword IS NULL
            OR f2.Question LIKE CONCAT('%', v_keyword, '%')
            OR f2.Answer LIKE CONCAT('%', v_keyword, '%')
        );

END $$
DELIMITER ;

-- GET FAQ BY ID
DROP PROCEDURE IF EXISTS sp_GetFaqById;
DELIMITER $$

CREATE PROCEDURE sp_GetFaqById(IN p_Id BIGINT)
BEGIN
    SELECT
        f.Id,
        f.Question AS Question,
        f.Answer,
        f.CategoryId,
        c.Name AS CategoryName,
        GROUP_CONCAT(DISTINCT t.Name ORDER BY t.Name SEPARATOR ', ') AS Tags
    FROM faq f
    JOIN category c ON c.Id = f.CategoryId AND c.IsActive = 1
    LEFT JOIN faq_tag ft ON ft.FaqId = f.Id AND ft.IsActive = 1
    LEFT JOIN tag t ON t.Id = ft.TagId AND t.IsActive = 1
    WHERE f.Id = p_Id
      AND f.IsActive = 1
    GROUP BY f.Id;
END $$
DELIMITER ;

-- CREATE FAQ (returns NewId)
DROP PROCEDURE IF EXISTS sp_CreateFaq;
DELIMITER $$

CREATE PROCEDURE sp_CreateFaq(
    IN p_Question TEXT,
    IN p_Answer TEXT,
    IN p_CategoryId BIGINT,
    IN p_CreatedBy BIGINT
)
BEGIN
    INSERT INTO faq (Question, Answer, CategoryId, CreatedBy, CreatedAt, UpdatedAt)
    VALUES (p_Question, p_Answer, p_CategoryId, p_CreatedBy, NOW(), NOW());

    SELECT LAST_INSERT_ID() AS NewId;
END $$

DELIMITER ;

-- UPDATE FAQ
DROP PROCEDURE IF EXISTS sp_UpdateFaq;
DELIMITER $$

CREATE PROCEDURE sp_UpdateFaq(
    IN p_Id BIGINT,
    IN p_Question TEXT,
    IN p_Answer TEXT,
    IN p_CategoryId BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE faq
    SET
        Question = COALESCE(p_Question, Question),
        Answer = COALESCE(p_Answer, Answer),
        CategoryId = COALESCE(p_CategoryId, CategoryId),
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id;
END $$

DELIMITER ;

-- DELETE FAQ (soft-delete)
DROP PROCEDURE IF EXISTS sp_DeleteFaq;
DELIMITER $$

CREATE PROCEDURE sp_DeleteFaq(
    IN p_Id BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE faq
    SET 
        IsActive = 0,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id;
END $$

DELIMITER ;

-- REMOVE FAQ TAG
DROP PROCEDURE IF EXISTS sp_RemoveFaqTag;
DELIMITER $$

CREATE PROCEDURE sp_RemoveFaqTag(
    IN p_FaqId BIGINT,
    IN p_TagId BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE faq_tag
    SET 
        IsActive = 0,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE FaqId = p_FaqId 
      AND TagId = p_TagId;
END $$

DELIMITER ;

-- REMOVE ALL TAGS FROM FAQ
DROP PROCEDURE IF EXISTS sp_RemoveAllTagsFromFaq;
DELIMITER $$

CREATE PROCEDURE sp_RemoveAllTagsFromFaq(
    IN p_FaqId BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE faq_tag
    SET 
        IsActive = 0,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE FaqId = p_FaqId;
END $$

DELIMITER ;

-- ADD FAQ TAGS FROM JSON ARRAY
DROP PROCEDURE IF EXISTS sp_AddFaqTagsJson;
DELIMITER $$

CREATE PROCEDURE sp_AddFaqTagsJson(
    IN p_FaqId BIGINT,
    IN p_TagIdsJson JSON,
    IN p_UserId BIGINT
)
BEGIN
   --  IF p_TagIdsJson IS NULL OR JSON_LENGTH(p_TagIdsJson) = 0 THEN
--         RETURN;
--     END IF;

    DROP TEMPORARY TABLE IF EXISTS tempTagIds;

    CREATE TEMPORARY TABLE tempTagIds (
        tagId BIGINT PRIMARY KEY
    );

    INSERT IGNORE INTO tempTagIds (tagId)
    SELECT DISTINCT CAST(j.tagId AS UNSIGNED)
    FROM JSON_TABLE(p_TagIdsJson, '$[*]' COLUMNS(
        tagId VARCHAR(100) PATH '$'
    )) AS j;

    INSERT INTO faq_tag (FaqId, TagId, CreatedBy, CreatedAt, UpdatedAt, IsActive)
    SELECT
        p_FaqId AS FaqId,
        t.tagId AS TagId,
        p_UserId AS CreatedBy,
        NOW() AS CreatedAt,
        NOW() AS UpdatedAt,
        1 AS IsActive
    FROM tempTagIds t
    LEFT JOIN faq_tag ft
        ON ft.FaqId = p_FaqId
       AND ft.TagId = t.tagId
       AND ft.IsActive = 1
    WHERE ft.FaqTagId IS NULL; 

    DROP TEMPORARY TABLE IF EXISTS tempTagIds;
END $$
DELIMITER ;


-- ------------------------------------------------------------------------------

-- sp_GetAllCategories
DROP PROCEDURE IF EXISTS sp_GetAllCategories;
DELIMITER $$

CREATE PROCEDURE sp_GetAllCategories(
    IN p_Page BIGINT,
    IN p_PageSize BIGINT,
    IN p_SearchKey VARCHAR(255)
)
BEGIN
    DECLARE v_page BIGINT;
    DECLARE v_pageSize BIGINT;
    DECLARE offsetRows BIGINT;
    DECLARE v_search VARCHAR(255);

    SET v_page = GREATEST(IFNULL(p_Page, 1), 1);
    SET v_pageSize = GREATEST(IFNULL(p_PageSize, 1), 1);
    SET offsetRows = (v_page - 1) * v_pageSize;
    SET v_search = NULLIF(TRIM(p_SearchKey), '');

    -- First result set: paged rows
    SELECT
        c.Id,
        c.Name,
        c.Description
    FROM category c
    WHERE 
        c.IsActive = 1
        AND (
            v_search IS NULL
            OR c.Name LIKE CONCAT('%', v_search, '%')
            OR c.Description LIKE CONCAT('%', v_search, '%')
        )
    ORDER BY c.Name ASC
    LIMIT v_pageSize OFFSET offsetRows;

    -- Second result set: total count
    SELECT COUNT(*) AS TotalCount
    FROM category c2
    WHERE c2.IsActive = 1
      AND (
          v_search IS NULL
          OR c2.Name LIKE CONCAT('%', v_search, '%')
          OR c2.Description LIKE CONCAT('%', v_search, '%')
      );
END $$
DELIMITER ;

-- sp_GetCategoryById
DROP PROCEDURE IF EXISTS sp_GetCategoryById;
DELIMITER $$

CREATE PROCEDURE sp_GetCategoryById(IN p_Id BIGINT)
BEGIN
    SELECT
        c.Id,
        c.Name,
        c.Description
    FROM category c
    WHERE c.Id = p_Id
	AND c.IsActive = 1;
END $$
DELIMITER ;

-- sp_CreateCategory (returns NewId)
DROP PROCEDURE IF EXISTS sp_CreateCategory;
DELIMITER $$

CREATE PROCEDURE sp_CreateCategory(
    IN p_Name VARCHAR(100),
    IN p_Description VARCHAR(255),
    IN p_CreatedBy BIGINT
)
BEGIN
    INSERT INTO category (Name, Description, CreatedBy, CreatedAt, UpdatedAt, IsActive)
    VALUES (p_Name, p_Description, p_CreatedBy, NOW(), NOW(), 1);

    SELECT LAST_INSERT_ID() AS NewId;
END $$
DELIMITER ;

-- sp_UpdateCategory
DROP PROCEDURE IF EXISTS sp_UpdateCategory;
DELIMITER $$

CREATE PROCEDURE sp_UpdateCategory(
    IN p_Id BIGINT,
    IN p_Name VARCHAR(100),
    IN p_Description VARCHAR(255),
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE category
    SET
        Name = COALESCE(p_Name, Name),
        Description = COALESCE(p_Description, Description),
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id
      AND IsActive = 1;
END $$
DELIMITER ;

-- sp_DeleteCategory (soft-delete)
DROP PROCEDURE IF EXISTS sp_DeleteCategory;
DELIMITER $$

CREATE PROCEDURE sp_DeleteCategory(
    IN p_Id BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE category
    SET
        IsActive = 0,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id;
END $$
DELIMITER ;


-- -------------------------------------------------------

-- sp_GetAllTags
DROP PROCEDURE IF EXISTS sp_GetAllTags;
DELIMITER $$

CREATE PROCEDURE sp_GetAllTags(
    IN p_Page BIGINT,
    IN p_PageSize BIGINT,
    IN p_SearchKey VARCHAR(255)
)
BEGIN
    DECLARE offsetRows BIGINT;
    SET offsetRows = (GREATEST(p_Page,1)-1) * GREATEST(p_PageSize,1);

    SELECT
        q.Id,
        q.Name,
        totals.TotalCount AS TotalCount
    FROM
    (
        SELECT
            t.Id,
            t.Name
        FROM tag t
        WHERE t.IsActive = 1
          AND (p_SearchKey IS NULL OR TRIM(p_SearchKey) = '' 
               OR t.Name LIKE CONCAT('%', p_SearchKey, '%'))
        ORDER BY t.Name ASC
        LIMIT p_PageSize OFFSET offsetRows
    ) AS q
    CROSS JOIN
    (
        SELECT COUNT(*) AS TotalCount
        FROM tag t2
        WHERE t2.IsActive = 1
          AND (p_SearchKey IS NULL OR TRIM(p_SearchKey) = '' 
               OR t2.Name LIKE CONCAT('%', p_SearchKey, '%'))
    ) AS totals;
END $$

DELIMITER ;

-- sp_GetTagById
DROP PROCEDURE IF EXISTS sp_GetTagById;
DELIMITER $$
CREATE PROCEDURE sp_GetTagById(IN p_Id BIGINT)
BEGIN
    SELECT
        t.Id,
        t.Name
    FROM tag t
    WHERE t.Id = p_Id
      AND t.IsActive = 1;
END $$
DELIMITER ;

DROP PROCEDURE IF EXISTS sp_CreateTag;
DELIMITER $$
CREATE PROCEDURE sp_CreateTag(
    IN p_Name VARCHAR(100),
    IN p_CreatedBy BIGINT
)
BEGIN
    INSERT INTO tag (Name, CreatedBy, CreatedAt, UpdatedAt, IsActive)
    VALUES (p_Name, p_CreatedBy, NOW(), NOW(), 1);

    SELECT LAST_INSERT_ID() AS NewId;
END $$

DELIMITER ;

-- sp_UpdateTag
DROP PROCEDURE IF EXISTS sp_UpdateTag;
DELIMITER $$
CREATE PROCEDURE sp_UpdateTag(
    IN p_Id BIGINT,
    IN p_Name VARCHAR(100),
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE tag
    SET
        Name = COALESCE(p_Name, Name),
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id
      AND IsActive = 1;
END $$
DELIMITER ;

-- sp_DeleteTag (soft-delete)
DROP PROCEDURE IF EXISTS sp_DeleteTag;
DELIMITER $$
CREATE PROCEDURE sp_DeleteTag(
    IN p_Id BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE tag
    SET IsActive = 0, UpdatedBy = p_UpdatedBy, UpdatedAt = NOW()
    WHERE Id = p_Id;
END $$
DELIMITER ;
 

-- ---------------------------------------------------------------------------

-- sp_CreateUser
DROP PROCEDURE IF EXISTS sp_CreateUser;
DELIMITER $$
CREATE PROCEDURE sp_CreateUser(
    IN p_UserName VARCHAR(100),
    IN p_Email VARCHAR(255),
    IN p_PasswordHash VARCHAR(255),
    IN p_CreatedBy BIGINT
)
BEGIN
    INSERT INTO `user` (UserName, Email, password_hash, CreatedBy, CreatedAt, UpdatedAt, IsActive)
    VALUES (p_UserName, p_Email, p_PasswordHash, p_CreatedBy, NOW(), NOW(), 1);

    SELECT LAST_INSERT_ID() AS NewId;
END $$
DELIMITER ;

-- sp_GetUserById
DROP PROCEDURE IF EXISTS sp_GetUserById;
DELIMITER $$
CREATE PROCEDURE sp_GetUserById(IN p_Id BIGINT)
BEGIN
    SELECT
        u.Id,
        u.UserName,
        u.Email
    FROM `user` u
    WHERE u.Id = p_Id
      AND u.IsActive = 1;
END $$
DELIMITER ;

-- sp_UpdateUser
DROP PROCEDURE IF EXISTS sp_UpdateUser;
DELIMITER $$
CREATE PROCEDURE sp_UpdateUser(
    IN p_Id BIGINT,
    IN p_UserName VARCHAR(100),
    IN p_Email VARCHAR(255),
    IN p_PasswordHash VARCHAR(255),
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE `user`
    SET
        UserName = COALESCE(p_UserName, UserName),
        Email = COALESCE(p_Email, Email),
        password_hash = CASE WHEN p_PasswordHash IS NULL OR p_PasswordHash = '' THEN password_hash ELSE p_PasswordHash END,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id
      AND IsActive = 1;
END $$
DELIMITER ;

-- sp_DeleteUser (soft-delete)
DROP PROCEDURE IF EXISTS sp_DeleteUser;
DELIMITER $$
CREATE PROCEDURE sp_DeleteUser(
    IN p_Id BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE `user`
    SET IsActive = 0,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id;
END $$
DELIMITER ;

DROP PROCEDURE IF EXISTS sp_GetUserByUsername;
DELIMITER $$

CREATE PROCEDURE sp_GetUserByUsername(IN p_UserName VARCHAR(100))
BEGIN
    SELECT Id, UserName, Email, password_hash
    FROM `user`
    WHERE UserName = p_UserName
    LIMIT 1;
END $$

DELIMITER ;

