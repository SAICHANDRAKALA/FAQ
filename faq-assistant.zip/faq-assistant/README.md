# FAQ Assistant Backend

## Overview

This is the backend for the FAQ Assistant system, built with ASP.NET Core and MySQL. It provides RESTful APIs for managing FAQs, categories, tags, and users, and includes an AI-powered endpoint for suggesting answers.

---

## Prerequisites

- [.NET 7.0 SDK or later](https://dotnet.microsoft.com/download/dotnet/7.0)
- [MySQL Server](https://dev.mysql.com/downloads/mysql/)
- (Optional) [Postman](https://www.postman.com/downloads/) for API testing

---

## Setup Instructions

### 1. Clone the Repository

```sh
git clone <your-repo-url>
cd "FAQ Assistant/faq-assistant"
```

### 2. Set Up the Database

1. **Create the database and all tables, procedures, and seed data:**

   - Open a terminal or MySQL Workbench.
   - Run the consolidated schema script:

2. **Verify the database:**

   ```sql
   USE faq_assistant;
   SHOW TABLES;
   ```

---

### 3. Configure the API

1. Open `backend/FaqAssistant.Api/appsettings.json` (and/or `appsettings.Development.json`).
2. Update the connection string with your MySQL credentials:

   ```json
   "ConnectionStrings": {
     "DefaultConnection": "Server=localhost;Port=3306;Database=faq_assistant;Uid=root;Pwd=your_password;"
   }
   ```

3. (Optional) Add your Groq API key for AI answer suggestions:

   ```json
   "Groq": {
     "ApiKey": "your_groq_api_key_here",
     "Model": "mixtral-8x7b-32768"
   }
   ```

---

### 4. Build and Run the API

```sh
cd backend
dotnet restore FaqAssistant.Api.sln
dotnet build FaqAssistant.Api.sln
cd FaqAssistant.Api
dotnet run
```

The API will start (by default) at:  
`http://localhost:5078`

---

### 5. API Documentation & Testing

- **Swagger UI:**  
  Visit [http://localhost:5078/swagger/index.html](http://localhost:5078/swagger/index.html) for interactive API docs.

- **Postman Collection:**  
  Import `backend/FaqAssistant.Api/postman/faq-assistant.postman_collection.json` into Postman for ready-to-use requests.

- **Full API Documentation:**
See API_DOCUMENTATION.md for detailed endpoint documentation, example requests, and responses.

---

### 6. JWT Authentication:**
This project supports JWT (token-based) authentication for securing API endpoints. Below are the steps to configure, use, and troubleshoot JWT authentication. For now I have added Authentication only for User and Faq endpoints.
Add NuGet Packages 
# adjust version to match your project's TargetFramework (net6/net7/net8)
dotnet add FaqAssistant.Api package Microsoft.AspNetCore.Authentication.JwtBearer --version 8.0.0
dotnet add FaqAssistant.Business.Core package System.IdentityModel.Tokens.Jwt --version 8.14.0

## Example API Usage

To use the Suggest Answer (AI) endpoint, simply open Postman, import the provided collection (backend/FaqAssistant.Api/postman/faq-assistant.postman_collection.json), select the Suggest Answer request, and click Send. The request body is pre-filled—just hit send and you’ll get an AI-generated answer using GroqAI automatically.

### Suggest an Answer (AI)

```http
POST /api/faq/suggest-answer
Content-Type: application/json

{
  "question": "How do I reset my password?",
  "maxTokens": 500,
  "temperature": 0.7
}
```

---

## Response Structure

All API responses follow this structure:

```json
{
    "code": 200,
    "success": true,
    "messages": [
        "Suggested answer generated successfully."
    ],
    "data": {
        "suggestedAnswer": "**Updating Billing Information:**\n\n1. Log in to your account on our website or mobile app.\n2. Click on your profile or account settings.\n3. Select 'Billing' or 'Payment Methods' from the dropdown menu.\n4. Update your credit card information, address, or other billing details as needed.\n5. Click 'Save Changes' to confirm the update.\n\nIf you're experiencing issues, contact our support team for assistance."
    }
}
```

## UnitTestCases
Unit tests are provided for all key API endpoints (FAQ, Category, Tag, and User controllers).
These tests use the xUnit framework and Moq for mocking dependencies.

How to Run the Tests
1. Open a terminal and navigate to the backend directory: cd "d:/FAQ Assistant/faq-assistant/backend"
2. Run the tests using the .NET CLI: dotnet test FaqAssistant.Api.Test/FaqAssistant.Api.Test.csproj

The test results will be displayed in the terminal.

---

## Troubleshooting

- **Database connection errors:**  
  - Ensure MySQL is running and the connection string is correct.
- **Port conflicts:**  
  - Change the port in `Properties/launchSettings.json` if needed.
- **Stored procedure errors:**  
  - Make sure you ran the full `database/schema.sql` script.

---

## Project Structure

- `backend/FaqAssistant.Api/` - API project (controllers, startup)
- `backend/FaqAssistant.Business.Core/` - Business logic
- `backend/FaqAssistant.DataAccess.Core/` - Data access (repositories)
- `backend/FaqAssistant.Model/` - DTOs and models
- `database/schema.sql` - All DB tables, procedures, and seed data

---