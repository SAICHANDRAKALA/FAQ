# API Documentation

Base URL:  
`http://localhost:5078/api`

---

## Category Endpoints

### Create Category

**POST** `/categories`

**Request:**
```json
{
  "name": "Billing",
  "description": "Billing related questions",
  "createdBy": 1
}

**Response:**
{
  "code": 201,
  "success": true,
  "messages": ["Category created successfully."],
  "data": { "id": 1 }
}

Get All Categories (Paged)
GET /categories?page=1&pageSize=10&searchKey=

Response:
{
  "code": 200,
  "success": true,
  "messages": ["Categories fetched successfully."],
  "data": {
    "page": 1,
    "pageSize": 10,
    "total": 2,
    "items": [
      { "id": 1, "name": "Billing", "description": "Billing related questions" },
      { "id": 2, "name": "Technical", "description": "Technical support" }
    ]
  }
}

Get Category by ID
GET /categories/{id}

Response:
{
  "code": 200,
  "success": true,
  "messages": ["Category fetched successfully."],
  "data": { "id": 1, "name": "Billing", "description": "Billing related questions" }
}

Update Category
PUT /categories/{id}

Request:
{
  "name": "Billing & Payments",
  "description": "Updated description",
  "updatedBy": 1
}

Delete Category
DELETE /categories/{id}?deletedBy=1

Response:

{
  "code": 200,
  "success": true,
  "messages": ["Category deleted successfully."],
  "data": null
}

------------------------------------------------

FAQ Endpoints
Create FAQ
POST /faq

Request:
{
  "question": "How do I view my invoice?",
  "answer": "Go to Billing > Invoices.",
  "categoryId": 1,
  "tagIds": [1, 2],
  "createdBy": 1
}
Response:
{
  "code": 201,
  "success": true,
  "messages": ["FAQ created successfully."],
  "data": { "id": 1 }
}
Get All FAQs (Paged & Filtered)
POST /faq/list

Request:
{
  "categoryId": 0,
  "tag": "",
  "keyword": "",
  "page": 1,
  "pageSize": 10
}
Response:

{
  "code": 200,
  "success": true,
  "messages": ["FAQs fetched successfully."],
  "data": {
    "page": 1,
    "pageSize": 10,
    "total": 1,
    "items": [
      {
        "id": 1,
        "question": "How do I view my invoice?",
        "answer": "Go to Billing > Invoices.",
        "categoryId": 1,
        "tags": ["Billing", "Invoice"]
      }
    ]
  }
}

Get FAQ by ID
GET /faq/{id}

Response:
{
  "code": 200,
  "success": true,
  "messages": ["FAQ fetched successfully."],
  "data": {
    "id": 1,
    "question": "How do I view my invoice?",
    "answer": "Go to Billing > Invoices.",
    "categoryId": 1,
    "tags": ["Billing", "Invoice"]
  }
}

Update FAQ
PUT /faq/{id}

Request:
{
  "question": "How do I view my invoice?",
  "answer": "Go to Billing > Invoices.",
  "categoryId": 1,
  "tagIds": [1, 2],
  "updatedBy": 1
}
Response:
{
  "code": 200,
  "success": true,
  "messages": ["FAQ updated successfully."],
  "data": null
}

Delete FAQ
DELETE /faq/{id}?deletedBy=1

Response:
{
  "code": 200,
  "success": true,
  "messages": ["FAQ deleted successfully."],
  "data": null
}

Add Tags to FAQ
POST /faq/{id}/tags?userId=1

Request:
[1, 2]
Response:
{
  "code": 200,
  "success": true,
  "messages": ["Tags added successfully."],
  "data": null
}

Remove Tag from FAQ
DELETE /faq/{id}/tags/{tagId}?updatedBy=1

Response:
{
  "code": 200,
  "success": true,
  "messages": ["Tag removed successfully."],
  "data": null
}

Suggest Answer (AI)
POST /faq/suggest

Request:
{
  "question": "How do I reset my password?",
  "maxTokens": 500,
  "temperature": 0.7
}
Response:
{
  "code": 200,
  "success": true,
  "messages": ["Suggested answer generated successfully."],
  "data": {
    "suggestedAnswer": "To reset your password, click on 'Forgot Password' at login and follow the instructions sent to your email."
  }
}


Tag Endpoints
Create Tag
POST /tags

Request:
{
  "name": "Invoice",
  "createdBy": 1
}
Response:
{
  "code": 201,
  "success": true,
  "messages": ["Tag created successfully."],
  "data": { "id": 1 }
}

Get All Tags (Paged)
GET /tags?page=1&pageSize=10&searchKey=

Response:
{
  "code": 200,
  "success": true,
  "messages": ["Tags fetched successfully."],
  "data": {
    "page": 1,
    "pageSize": 10,
    "total": 2,
    "items": [
      { "id": 1, "name": "Invoice" },
      { "id": 2, "name": "Payment" }
    ]
  }
}

Get Tag by ID
GET /tags/{id}

Response:
{
  "code": 200,
  "success": true,
  "messages": ["Tag fetched successfully."],
  "data": { "id": 1, "name": "Invoice" }
}

Update Tag
PUT /tags/{id}

Request:
{
  "name": "Invoice Updated",
  "updatedBy": 1
}
Response:
{
  "code": 200,
  "success": true,
  "messages": ["Tag updated successfully."],
  "data": null
}

Delete Tag
DELETE /tags/{id}?updatedBy=1

Response:
{
  "code": 200,
  "success": true,
  "messages": ["Tag deleted successfully."],
  "data": null
}

User Endpoints
Create User
POST /users

Request:
{
  "username": "john_doe",
  "email": "john@example.com",
  "createdBy": 1
}
Response:
{
  "code": 201,
  "success": true,
  "messages": ["User created successfully."],
  "data": { "id": 1 }
}

Get User by ID
GET /users/{id}

Response:
{
  "code": 200,
  "success": true,
  "messages": ["User fetched successfully."],
  "data": { "id": 1, "username": "john_doe", "email": "john@example.com" }
}

Update User
PUT /users/{id}

Request:
{
  "username": "john_doe_updated",
  "email": "john_updated@example.com",
  "updatedBy": 1
}
Response:
{
  "code": 200,
  "success": true,
  "messages": ["User updated successfully."],
  "data": null
}

Delete User
DELETE /users/{id}?updatedBy=1

Response:
{
  "code": 200,
  "success": true,
  "messages": ["User deleted successfully."],
  "data": null
}
