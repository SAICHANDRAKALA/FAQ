# FAQ Assistant Backend

This is the backend for the FAQ Assistant system, built using ASP.NET Core Web API. The backend provides a RESTful API for managing FAQs, categories, and tags, and connects to a MySQL database.

## Project Structure

- **FaqAssistant.Api.sln**: Solution file for the ASP.NET Core Web API project.
- **Controllers**: Contains controllers that handle HTTP requests.
  - **FaqController.cs**: Manages CRUD operations for FAQs.
- **Models**: Contains data models.
  - **FaqItem.cs**: Represents the FAQ entity.
- **Data**: Contains the database context.
  - **FaqContext.cs**: Manages the database context and entities.
- **Services**: Contains business logic.
  - **FaqService.cs**: Provides methods for managing FAQs.
- **appsettings.json**: Configuration settings for the application.
- **Program.cs**: Entry point of the application.

## Setup Instructions

1. **Clone the Repository**: 
   ```
   git clone <repository-url>
   cd faq-assistant/backend
   ```

2. **Install Dependencies**: 
   Ensure you have the .NET SDK installed. Run the following command to restore the dependencies:
   ```
   dotnet restore
   ```

3. **Configure Database**: 
   Update the `appsettings.json` file with your MySQL connection string.

4. **Run Migrations**: 
   If using Entity Framework, run the migrations to set up the database:
   ```
   dotnet ef database update
   ```

5. **Start the Application**: 
   Run the application using:
   ```
   dotnet run
   ```

## API Usage

- **GET /api/faqs**: Retrieve all FAQs.
- **GET /api/faqs/{id}**: Retrieve a specific FAQ by ID.
- **POST /api/faqs**: Create a new FAQ.
- **PUT /api/faqs/{id}**: Update an existing FAQ.
- **DELETE /api/faqs/{id}**: Delete a specific FAQ.

## Frontend Integration

The backend is designed to work with an Angular frontend. Ensure the frontend is set up to make API calls to the backend endpoints.

## License

This project is licensed under the MIT License.