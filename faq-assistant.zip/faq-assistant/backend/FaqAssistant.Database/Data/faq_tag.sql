DROP TEMPORARY TABLE IF EXISTS tempFaqTag;

CREATE TEMPORARY TABLE tempFaqTag (
    FaqTagId BIGINT AUTO_INCREMENT PRIMARY KEY,
    FaqId BIGINT NOT NULL,
    TagId BIGINT NOT NULL,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempFaqTag
(FaqTagId, FaqId, TagId, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1, 1, 1, 1, NULL, NOW(), NOW()), -- FAQ 1 -> General
(2, 1, 8, 1, NULL, NOW(), NOW()), -- FAQ 1 -> Password (if relevant)
(3, 2, 8, 1, NULL, NOW(), NOW()), -- FAQ 2 -> Password
(4, 2, 9, 1, NULL, NOW(), NOW()), -- FAQ 2 -> Login
(5, 3, 4, 1, NULL, NOW(), NOW()), -- FAQ 3 -> Bug
(6, 4, 6, 1, NULL, NOW(), NOW()), -- FAQ 4 -> Subscription
(7, 5, 7, 1, NULL, NOW(), NOW()), -- FAQ 5 -> Refund
(8, 6, 11, 1, NULL, NOW(), NOW()), -- FAQ 6 -> API
(9, 6, 12, 1, NULL, NOW(), NOW()), -- FAQ 6 -> Integration
(10, 7, 13, 1, NULL, NOW(), NOW()), -- FAQ 7 -> Security
(11, 8, 10, 1, NULL, NOW(), NOW()), -- FAQ 8 -> Mobile
(12, 9, 12, 1, NULL, NOW(), NOW()), -- FAQ 9 -> Integration
(13, 10, 1, 1, NULL, NOW(), NOW()), -- FAQ 10 -> General
(14, 11, 14, 1, NULL, NOW(), NOW()), -- FAQ 11 -> Performance
(15, 12, 13, 1, NULL, NOW(), NOW()); -- FAQ 12 -> Security

SET SQL_SAFE_UPDATES = 0;

UPDATE faq_tag ft
JOIN tempFaqTag temp
    ON ft.FaqTagId = temp.FaqTagId
SET
    ft.FaqId = temp.FaqId,
    ft.TagId = temp.TagId,
    ft.CreatedBy = temp.CreatedBy,
    ft.UpdatedBy = temp.UpdatedBy,
    ft.CreatedAt = temp.CreatedAt,
    ft.UpdatedAt = temp.UpdatedAt;

INSERT INTO faq_tag
(FaqTagId, FaqId, TagId, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.FaqTagId,
    temp.FaqId,
    temp.TagId,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempFaqTag temp
LEFT JOIN faq_tag ft
    ON ft.FaqTagId = temp.FaqTagId
WHERE ft.FaqTagId IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempFaqTag;
