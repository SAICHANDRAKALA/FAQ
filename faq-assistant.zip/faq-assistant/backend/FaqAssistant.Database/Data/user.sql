DROP TEMPORARY TABLE IF EXISTS tempUser;

CREATE TEMPORARY TABLE tempUser (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    UserName VARCHAR(100) NOT NULL UNIQUE,
    Email VARCHAR(255) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempUser
(Id, UserName, Email, password_hash, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1, 'admin', 'admin@example.com', '$2a$10$gTjVNY9mQxQWnV9Lz0qvEOPGAJ8i6j7lH.Hm3MX0Zn7E35V7Sbn6C', 1, NULL, NOW(), NOW()),
(2, 'alice', 'alice@example.com', '$2a$10$BVpK8u94G1sm4Gx0JjH4tO81OJE9vZrjvDX2vZ9fFnmL0NwVt0KWK', 1, NULL, NOW(), NOW()),
(3, 'bob', 'bob@example.com', '$2a$10$vDcksyzqpbJtOk6xTtbF2OXeOIVhQYZBXK2ST6uuc2bhJtHqdVxzu', 1, NULL, NOW(), NOW()),
(4, 'support', 'support@example.com', '$2a$10$abcdefghabcdefghabcdefghabcdefghabcdefghabcdefghabcdef', 1, NULL, NOW(), NOW());

SET SQL_SAFE_UPDATES = 0;

UPDATE `user` u
JOIN tempUser temp
  ON u.Id = temp.Id
SET
    u.UserName = temp.UserName,
    u.Email = temp.Email,
    u.password_hash = temp.password_hash,
    u.CreatedBy = temp.CreatedBy,
    u.UpdatedBy = temp.UpdatedBy,
    u.CreatedAt = temp.CreatedAt,
    u.UpdatedAt = temp.UpdatedAt;

INSERT INTO `user`
(Id, UserName, Email, password_hash, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.Id,
    temp.UserName,
    temp.Email,
    temp.password_hash,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempUser temp
LEFT JOIN `user` u
    ON u.Id = temp.Id
WHERE u.Id IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempUser;
