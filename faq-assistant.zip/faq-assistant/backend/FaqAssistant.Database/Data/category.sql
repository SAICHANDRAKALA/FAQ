DROP TEMPORARY TABLE IF EXISTS tempCategory;

CREATE TEMPORARY TABLE tempCategory (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL UNIQUE,
    Description VARCHAR(255),
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempCategory
(Id, Name, Description, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1, 'Billing', 'Questions related to billing and payments', 1, NULL, NOW(), NOW()),
(2, 'Account Setup', 'Questions about creating and configuring accounts', 1, NULL, NOW(), NOW()),
(3, 'Technical', 'Technical troubleshooting and support', 1, NULL, NOW(), NOW()),
(4, 'Subscriptions', 'Subscription plans, upgrades and cancellations', 1, NULL, NOW(), NOW()),
(5, 'Integrations', 'API, webhooks and 3rd-party integrations', 1, NULL, NOW(), NOW()),
(6, 'Security', 'Account security, 2FA and permissions', 1, NULL, NOW(), NOW());

SET SQL_SAFE_UPDATES = 0;

UPDATE category c
JOIN tempCategory temp
  ON c.Id = temp.Id
SET
    c.Name = temp.Name,
    c.Description = temp.Description,
    c.CreatedBy = temp.CreatedBy,
    c.UpdatedBy = temp.UpdatedBy,
    c.CreatedAt = temp.CreatedAt,
    c.UpdatedAt = temp.UpdatedAt;

INSERT INTO category
(Id, Name, Description, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.Id,
    temp.Name,
    temp.Description,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempCategory temp
LEFT JOIN category c
    ON c.Id = temp.Id
WHERE c.Id IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempCategory;
