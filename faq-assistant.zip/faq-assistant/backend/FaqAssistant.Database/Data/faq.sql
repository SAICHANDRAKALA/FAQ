DROP TEMPORARY TABLE IF EXISTS tempFaq;

CREATE TEMPORARY TABLE tempFaq (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    Question TEXT NOT NULL,
    Answer TEXT,
    CategoryId BIGINT NOT NULL,
    IsActive TINYINT DEFAULT 1,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempFaq
(Id, Question, Answer, CategoryId, IsActive, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1,
 'How can I view my billing history?',
 'You can view your billing history from the Billing section under your account settings. Select the Billing tab and choose the date range to export invoices.',
 1, 1, 1, NULL, NOW(), NOW()),

(2,
 'How do I reset my account password?',
 'Click on “Forgot Password” on the login page and follow the instructions sent to your email. If you do not receive the email, check spam or contact support.',
 2, 1, 1, NULL, NOW(), NOW()),

(3,
 'Why is my application not loading?',
 'This issue is usually caused by network restrictions or a missing update. Try clearing your browser cache and ensure you are on the latest supported browser version.',
 3, 1, 1, NULL, NOW(), NOW()),

(4,
 'How do I cancel my subscription?',
 'To cancel, go to your Account > Subscription page, choose Cancel Plan, and confirm. Cancellation will stop future billing but your account remains active until the period ends.',
 4, 1, 1, NULL, NOW(), NOW()),

(5,
 'How do I get a refund for a charge?',
 'Refunds are processed on a case-by-case basis. Open a support ticket with your invoice number and we will review within 5–7 business days.',
 1, 1, 1, NULL, NOW(), NOW()),

(6,
 'How do I integrate with the API?',
 'Refer to our API docs at /docs/api. You will find request examples, auth headers, and SDK links. Use your API key under Account > API Keys.',
 5, 1, 1, NULL, NOW(), NOW()),

(7,
 'How can I enable two-factor authentication (2FA)?',
 'Enable 2FA via Account > Security. Install an authenticator app and scan the QR code. Keep your backup codes stored securely.',
 6, 1, 1, NULL, NOW(), NOW()),

(8,
 'Why is my mobile app crashing on startup?',
 'Ensure the mobile app is updated. If issue persists, reinstall the app, check permissions, and capture logs to share with support.',
 3, 1, 1, NULL, NOW(), NOW()),

(9,
 'How do webhooks work?',
 'Webhooks POST JSON payloads to your callback URL. Subscribe under Integrations > Webhooks and test deliverability from the dashboard.',
 5, 1, 1, NULL, NOW(), NOW()),

(10,
 'How do I change my billing email address?',
 'Update billing email at Account > Billing > Edit Contact. You will receive a verification email to confirm the change.',
 1, 1, 1, NULL, NOW(), NOW()),

(11,
 'How to improve API response performance?',
 'Use bulk endpoints where possible, paginate requests, and cache repeated queries. Also ensure your network latency is low and request concurrency is limited.',
 3, 1, 1, NULL, NOW(), NOW()),

(12,
 'What should I do if I suspect my account was compromised?',
 'Immediately change your password, enable 2FA, and contact support. We can temporarily lock your account and review recent activity.',
 6, 1, 1, NULL, NOW(), NOW());

SET SQL_SAFE_UPDATES = 0;

UPDATE faq f
JOIN tempFaq temp
    ON f.Id = temp.Id
SET
    f.Question = temp.Question,
    f.Answer = temp.Answer,
    f.CategoryId = temp.CategoryId,
    f.IsActive = temp.IsActive,
    f.CreatedBy = temp.CreatedBy,
    f.UpdatedBy = temp.UpdatedBy,
    f.CreatedAt = temp.CreatedAt,
    f.UpdatedAt = temp.UpdatedAt;

INSERT INTO faq
(Id, Question, Answer, CategoryId, IsActive, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.Id,
    temp.Question,
    temp.Answer,
    temp.CategoryId,
    temp.IsActive,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempFaq temp
LEFT JOIN faq f
    ON f.Id = temp.Id
WHERE f.Id IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempFaq;
