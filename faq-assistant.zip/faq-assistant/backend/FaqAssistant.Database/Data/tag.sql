DROP TEMPORARY TABLE IF EXISTS tempTag;

CREATE TEMPORARY TABLE tempTag (
    Id BIGINT AUTO_INCREMENT PRIMARY KEY,
    Name VARCHAR(100) NOT NULL UNIQUE,
    CreatedBy BIGINT NOT NULL,
    UpdatedBy BIGINT,
    CreatedAt DATETIME DEFAULT CURRENT_TIMESTAMP,
    UpdatedAt DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

INSERT INTO tempTag
(Id, Name, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
VALUES
(1, 'General', 1, NULL, NOW(), NOW()),
(2, 'Urgent', 1, NULL, NOW(), NOW()),
(3, 'Feature Request', 1, NULL, NOW(), NOW()),
(4, 'Bug', 1, NULL, NOW(), NOW()),
(5, 'How-To', 1, NULL, NOW(), NOW()),
(6, 'Subscription', 1, NULL, NOW(), NOW()),
(7, 'Refund', 1, NULL, NOW(), NOW()),
(8, 'Password', 1, NULL, NOW(), NOW()),
(9, 'Login', 1, NULL, NOW(), NOW()),
(10, 'Mobile', 1, NULL, NOW(), NOW()),
(11, 'API', 1, NULL, NOW(), NOW()),
(12, 'Integration', 1, NULL, NOW(), NOW()),
(13, 'Security', 1, NULL, NOW(), NOW()),
(14, 'Performance', 1, NULL, NOW(), NOW());

SET SQL_SAFE_UPDATES = 0;

UPDATE tag t
JOIN tempTag temp
  ON t.Id = temp.Id
SET
    t.Name = temp.Name,
    t.CreatedBy = temp.CreatedBy,
    t.UpdatedBy = temp.UpdatedBy,
    t.CreatedAt = temp.CreatedAt,
    t.UpdatedAt = temp.UpdatedAt;

INSERT INTO tag
(Id, Name, CreatedBy, UpdatedBy, CreatedAt, UpdatedAt)
SELECT
    temp.Id,
    temp.Name,
    temp.CreatedBy,
    temp.UpdatedBy,
    temp.CreatedAt,
    temp.UpdatedAt
FROM tempTag temp
LEFT JOIN tag t
    ON t.Id = temp.Id
WHERE t.Id IS NULL;

SET SQL_SAFE_UPDATES = 1;

DROP TEMPORARY TABLE IF EXISTS tempTag;
