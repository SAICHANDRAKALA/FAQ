DROP PROCEDURE IF EXISTS sp_UpdateCategory;
DELIMITER $$

CREATE PROCEDURE sp_UpdateCategory(
    IN p_Id BIGINT,
    IN p_Name VARCHAR(100),
    IN p_Description VARCHAR(255),
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE category
    SET
        Name = COALESCE(p_Name, Name),
        Description = COALESCE(p_Description, Description),
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id
      AND IsActive = 1;
END $$
DELIMITER ;