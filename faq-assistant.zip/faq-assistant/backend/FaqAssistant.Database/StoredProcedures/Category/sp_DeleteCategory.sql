DROP PROCEDURE IF EXISTS sp_DeleteCategory;
DELIMITER $$

CREATE PROCEDURE sp_DeleteCategory(
    IN p_Id BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE category
    SET
        IsActive = 0,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id;
END $$
DELIMITER ;