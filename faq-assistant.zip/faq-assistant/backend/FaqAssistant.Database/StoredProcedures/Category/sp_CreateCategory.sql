DROP PROCEDURE IF EXISTS sp_CreateCategory;
DELIMITER $$

CREATE PROCEDURE sp_CreateCategory(
    IN p_Name VARCHAR(100),
    IN p_Description VARCHAR(255),
    IN p_CreatedBy BIGINT
)
BEGIN
    INSERT INTO category (Name, Description, CreatedBy, CreatedAt, UpdatedAt, IsActive)
    VALUES (p_Name, p_Description, p_CreatedBy, NOW(), NOW(), 1);

    SELECT LAST_INSERT_ID() AS NewId;
END $$
DELIMITER ;