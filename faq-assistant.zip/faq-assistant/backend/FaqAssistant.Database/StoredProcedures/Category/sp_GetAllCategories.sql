DROP PROCEDURE IF EXISTS sp_GetAllCategories;
DELIMITER $$

CREATE PROCEDURE sp_GetAllCategories(
    IN p_Page BIGINT,
    IN p_PageSize BIGINT,
    IN p_SearchKey VARCHAR(255)
)
BEGIN
    DECLARE v_page BIGINT;
    DECLARE v_pageSize BIGINT;
    DECLARE offsetRows BIGINT;
    DECLARE v_search VARCHAR(255);

    SET v_page = GREATEST(IFNULL(p_Page, 1), 1);
    SET v_pageSize = GREATEST(IFNULL(p_PageSize, 1), 1);
    SET offsetRows = (v_page - 1) * v_pageSize;
    SET v_search = NULLIF(TRIM(p_SearchKey), '');

    -- First result set: paged rows
    SELECT
        c.Id,
        c.Name,
        c.Description
    FROM category c
    WHERE 
        c.IsActive = 1
        AND (
            v_search IS NULL
            OR c.Name LIKE CONCAT('%', v_search, '%')
            OR c.Description LIKE CONCAT('%', v_search, '%')
        )
    ORDER BY c.Name ASC
    LIMIT v_pageSize OFFSET offsetRows;

    -- Second result set: total count
    SELECT COUNT(*) AS TotalCount
    FROM category c2
    WHERE c2.IsActive = 1
      AND (
          v_search IS NULL
          OR c2.Name LIKE CONCAT('%', v_search, '%')
          OR c2.Description LIKE CONCAT('%', v_search, '%')
      );
END $$
DELIMITER ;
