DROP PROCEDURE IF EXISTS sp_GetCategoryById;
DELIMITER $$

CREATE PROCEDURE sp_GetCategoryById(IN p_Id BIGINT)
BEGIN
    SELECT
        c.Id,
        c.Name,
        c.Description,
    FROM category c
    WHERE c.Id = p_Id
	AND c.IsActive = 1;
END $$
DELIMITER ;