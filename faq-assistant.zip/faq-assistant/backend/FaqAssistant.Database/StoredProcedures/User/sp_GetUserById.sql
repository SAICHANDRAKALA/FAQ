DROP PROCEDURE IF EXISTS sp_GetUserById;
DELIMITER $$
CREATE PROCEDURE sp_GetUserById(IN p_Id BIGINT)
BEGIN
    SELECT
        u.Id,
        u.UserName,
        u.Email
    FROM `user` u
    WHERE u.Id = p_Id
      AND u.IsActive = 1;
END $$
DELIMITER ;