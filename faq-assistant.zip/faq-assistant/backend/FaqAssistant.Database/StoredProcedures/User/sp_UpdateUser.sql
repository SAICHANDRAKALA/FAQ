DROP PROCEDURE IF EXISTS sp_UpdateUser;
DELIMITER $$
CREATE PROCEDURE sp_UpdateUser(
    IN p_Id BIGINT,
    IN p_UserName VARCHAR(100),
    IN p_Email VARCHAR(255),
    IN p_PasswordHash VARCHAR(255),
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE `user`
    SET
        UserName = COALESCE(p_UserName, UserName),
        Email = COALESCE(p_Email, Email),
        password_hash = CASE WHEN p_PasswordHash IS NULL OR p_PasswordHash = '' THEN password_hash ELSE p_PasswordHash END,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id
      AND IsActive = 1;
END $$
DELIMITER ;