DROP PROCEDURE IF EXISTS sp_CreateUser;
DELIMITER $$
CREATE PROCEDURE sp_CreateUser(
    IN p_UserName VARCHAR(100),
    IN p_Email VARCHAR(255),
    IN p_PasswordHash VARCHAR(255),
    IN p_CreatedBy BIGINT
)
BEGIN
    INSERT INTO `user` (UserName, Email, password_hash, CreatedBy, CreatedAt, UpdatedAt, IsActive)
    VALUES (p_UserName, p_Email, p_PasswordHash, p_CreatedBy, NOW(), NOW(), 1);

    SELECT LAST_INSERT_ID() AS NewId;
END $$
DELIMITER ;
