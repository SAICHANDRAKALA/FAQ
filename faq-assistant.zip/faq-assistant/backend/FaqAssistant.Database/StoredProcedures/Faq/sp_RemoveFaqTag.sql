DROP PROCEDURE IF EXISTS sp_RemoveFaqTag;
DELIMITER $$

CREATE PROCEDURE sp_RemoveFaqTag(
    IN p_FaqId BIGINT,
    IN p_TagId BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE faq_tag
    SET 
        IsActive = 0,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE FaqId = p_FaqId 
      AND TagId = p_TagId;
END $$

DELIMITER ;
