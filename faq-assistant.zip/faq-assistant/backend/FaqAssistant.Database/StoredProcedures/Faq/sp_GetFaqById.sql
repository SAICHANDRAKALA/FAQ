DROP PROCEDURE IF EXISTS sp_GetFaqById;
DELIMITER $$

CREATE PROCEDURE sp_GetFaqById(IN p_Id BIGINT)
BEGIN
    SELECT
        f.Id,
        f.Auestion AS Question,
        f.Answer,
        f.CategoryId,
        c.Name AS CategoryName,
        GROUP_CONCAT(DISTINCT t.Name ORDER BY t.Name SEPARATOR ', ') AS Tags
    FROM faq f
    JOIN category c ON c.Id = f.CategoryId AND c.IsActive = 1
    LEFT JOIN faq_tag ft ON ft.FaqId = f.Id AND ft.IsActive = 1
    LEFT JOIN tag t ON t.Id = ft.TagId AND t.IsActive = 1
    WHERE f.Id = p_Id
      AND f.IsActive = 1
    GROUP BY f.Id;
END $$
DELIMITER ;