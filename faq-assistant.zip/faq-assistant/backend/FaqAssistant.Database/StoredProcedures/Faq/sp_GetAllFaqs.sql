DROP PROCEDURE IF EXISTS sp_GetAllFaqs;
DELIMITER $$

CREATE PROCEDURE sp_GetAllFaqs(
    IN p_CategoryId BIGINT,
    IN p_Tag VARCHAR(100),
    IN p_Keyword VARCHAR(255),
    IN p_Page BIGINT,
    IN p_PageSize BIGINT
)
BEGIN
    DECLARE v_page BIGINT DEFAULT 1;
    DECLARE v_pageSize BIGINT DEFAULT 20;
    DECLARE offsetRows BIGINT;
    DECLARE v_tag VARCHAR(100);
    DECLARE v_keyword VARCHAR(255);

    -- Normalize search inputs: empty => NULL
    SET v_tag = NULLIF(TRIM(p_Tag), '');
    SET v_keyword = NULLIF(TRIM(p_Keyword), '');

    -- Normalize pagination inputs but do NOT force a LIMIT if p_PageSize <= 0
    SET v_page = IFNULL(NULLIF(p_Page, 0), 1);
    SET v_pageSize = IFNULL(NULLIF(p_PageSize, 0), 20);
    SET offsetRows = (v_page - 1) * v_pageSize;

    -- ===== Result set 1: paged or all FAQ rows =====
    IF p_PageSize IS NOT NULL AND p_PageSize > 0 THEN
        SELECT
            f.Id,
            f.Question,
            f.Answer,
            f.CategoryId,
            c.Name AS CategoryName,
            GROUP_CONCAT(DISTINCT t.Name ORDER BY t.Name SEPARATOR ', ') AS Tags
        FROM faq f
        JOIN category c ON c.Id = f.CategoryId AND c.IsActive = 1
        LEFT JOIN faq_tag ft ON ft.FaqId = f.Id AND ft.IsActive = 1
        LEFT JOIN tag t ON t.Id = ft.TagId AND t.IsActive = 1
        WHERE
            f.IsActive = 1
            AND (p_CategoryId IS NULL OR p_CategoryId = 0 OR f.CategoryId = p_CategoryId)
            AND (
                v_tag IS NULL OR EXISTS (
                    SELECT 1
                    FROM faq_tag ft2
                    JOIN tag t2 ON t2.Id = ft2.TagId
                    WHERE ft2.FaqId = f.Id
                      AND ft2.IsActive = 1
                      AND t2.IsActive = 1
                      AND t2.Name LIKE CONCAT('%', v_tag, '%')
                )
            )
            AND (
                v_keyword IS NULL
                OR f.Question LIKE CONCAT('%', v_keyword, '%')
                OR f.Answer LIKE CONCAT('%', v_keyword, '%')
            )
        GROUP BY f.Id
        ORDER BY f.CreatedAt DESC
        LIMIT v_pageSize OFFSET offsetRows;
    ELSE
        -- No pagination requested: return ALL matching rows
        SELECT
            f.Id,
            f.Question,
            f.Answer,
            f.CategoryId,
            c.Name AS CategoryName,
            GROUP_CONCAT(DISTINCT t.Name ORDER BY t.Name SEPARATOR ', ') AS Tags
        FROM faq f
        JOIN category c ON c.Id = f.CategoryId AND c.IsActive = 1
        LEFT JOIN faq_tag ft ON ft.FaqId = f.Id AND ft.IsActive = 1
        LEFT JOIN tag t ON t.Id = ft.TagId AND t.IsActive = 1
        WHERE
            f.IsActive = 1
            AND (p_CategoryId IS NULL OR p_CategoryId = 0 OR f.CategoryId = p_CategoryId)
            AND (
                v_tag IS NULL OR EXISTS (
                    SELECT 1
                    FROM faq_tag ft2
                    JOIN tag t2 ON t2.Id = ft2.TagId
                    WHERE ft2.FaqId = f.Id
                      AND ft2.IsActive = 1
                      AND t2.IsActive = 1
                      AND t2.Name LIKE CONCAT('%', v_tag, '%')
                )
            )
            AND (
                v_keyword IS NULL
                OR f.Question LIKE CONCAT('%', v_keyword, '%')
                OR f.Answer LIKE CONCAT('%', v_keyword, '%')
            )
        GROUP BY f.Id
        ORDER BY f.CreatedAt DESC;
    END IF;

    -- ===== Result set 2: total count =====
    SELECT COUNT(DISTINCT f2.Id) AS TotalCount
    FROM faq f2
    JOIN category c2 ON c2.Id = f2.CategoryId AND c2.IsActive = 1
    LEFT JOIN faq_tag ft3 ON ft3.FaqId = f2.Id AND ft3.IsActive = 1
    LEFT JOIN tag t3 ON t3.Id = ft3.TagId AND t3.IsActive = 1
    WHERE
        f2.IsActive = 1
        AND (p_CategoryId IS NULL OR p_CategoryId = 0 OR f2.CategoryId = p_CategoryId)
        AND (
            v_tag IS NULL OR EXISTS (
                SELECT 1
                FROM faq_tag ft4
                JOIN tag t4 ON t4.Id = ft4.TagId
                WHERE ft4.FaqId = f2.Id
                  AND ft4.IsActive = 1
                  AND t4.IsActive = 1
                  AND t4.Name LIKE CONCAT('%', v_tag, '%')
            )
        )
        AND (
            v_keyword IS NULL
            OR f2.Question LIKE CONCAT('%', v_keyword, '%')
            OR f2.Answer LIKE CONCAT('%', v_keyword, '%')
        );

END $$
DELIMITER ;
