DROP PROCEDURE IF EXISTS sp_AddFaqTagsJson;
DELIMITER $$

CREATE PROCEDURE sp_AddFaqTagsJson(
    IN p_FaqId BIGINT,
    IN p_TagIdsJson JSON,
    IN p_UserId BIGINT
)
BEGIN
    IF p_TagIdsJson IS NULL OR JSON_LENGTH(p_TagIdsJson) = 0 THEN
        RETURN;
    END IF;

    DROP TEMPORARY TABLE IF EXISTS tempTagIds;

    CREATE TEMPORARY TABLE tempTagIds (
        tagId BIGINT PRIMARY KEY
    );

    INSERT IGNORE INTO tempTagIds (tagId)
    SELECT DISTINCT CAST(j.tagId AS UNSIGNED)
    FROM JSON_TABLE(p_TagIdsJson, '$[*]' COLUMNS(
        tagId VARCHAR(100) PATH '$'
    )) AS j;

    INSERT INTO faq_tag (FaqId, TagId, CreatedBy, CreatedAt, UpdatedAt, IsActive)
    SELECT
        p_FaqId AS FaqId,
        t.tagId AS TagId,
        p_UserId AS CreatedBy,
        NOW() AS CreatedAt,
        NOW() AS UpdatedAt,
        1 AS IsActive
    FROM tempTagIds t
    LEFT JOIN faq_tag ft
        ON ft.FaqId = p_FaqId
       AND ft.TagId = t.tagId
       AND ft.IsActive = 1
    WHERE ft.FaqTagId IS NULL; 
    
    DROP TEMPORARY TABLE IF EXISTS tempTagIds;
END $$
DELIMITER ;
