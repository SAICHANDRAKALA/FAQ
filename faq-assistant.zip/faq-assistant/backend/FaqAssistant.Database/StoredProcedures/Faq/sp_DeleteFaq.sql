DROP PROCEDURE IF EXISTS sp_DeleteFaq;
DELIMITER $$

CREATE PROCEDURE sp_DeleteFaq(
    IN p_Id BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE faq
    SET 
        IsActive = 0,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id;
END $$

DELIMITER ;
