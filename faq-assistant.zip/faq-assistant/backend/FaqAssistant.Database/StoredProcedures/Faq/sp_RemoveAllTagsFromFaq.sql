DROP PROCEDURE IF EXISTS sp_RemoveAllTagsFromFaq;
DELIMITER $$

CREATE PROCEDURE sp_RemoveAllTagsFromFaq(
    IN p_FaqId BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE faq_tag
    SET 
        IsActive = 0,
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE FaqId = p_FaqId;
END $$

DELIMITER ;
