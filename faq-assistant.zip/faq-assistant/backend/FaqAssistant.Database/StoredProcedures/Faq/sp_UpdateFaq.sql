DROP PROCEDURE IF EXISTS sp_UpdateFaq;
DELIMITER $$

CREATE PROCEDURE sp_UpdateFaq(
    IN p_Id BIGINT,
    IN p_Question TEXT,
    IN p_Answer TEXT,
    IN p_CategoryId BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE faq
    SET
        Auestion = COALESCE(p_Question, Auestion),
        Answer = COALESCE(p_Answer, Answer),
        CategoryId = COALESCE(p_CategoryId, CategoryId),
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id;
END $$

DELIMITER ;
