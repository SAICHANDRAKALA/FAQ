DROP PROCEDURE IF EXISTS sp_CreateFaq;
DELIMITER $$

CREATE PROCEDURE sp_CreateFaq(
    IN p_Question TEXT,
    IN p_Answer TEXT,
    IN p_CategoryId BIGINT,
    IN p_CreatedBy BIGINT
)
BEGIN
    INSERT INTO faq (Auestion, Answer, CategoryId, CreatedBy, CreatedAt, UpdatedAt)
    VALUES (p_Question, p_Answer, p_CategoryId, p_CreatedBy, NOW(), NOW());

    SELECT LAST_INSERT_ID() AS NewId;
END $$

DELIMITER ;
