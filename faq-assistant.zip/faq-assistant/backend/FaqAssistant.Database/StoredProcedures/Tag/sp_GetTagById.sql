DROP PROCEDURE IF EXISTS sp_GetTagById;
DELIMITER $$
CREATE PROCEDURE sp_GetTagById(IN p_Id BIGINT)
BEGIN
    SELECT
        t.Id,
        t.Name
    FROM tag t
    WHERE t.Id = p_Id
      AND t.IsActive = 1;
END $$
DELIMITER ;