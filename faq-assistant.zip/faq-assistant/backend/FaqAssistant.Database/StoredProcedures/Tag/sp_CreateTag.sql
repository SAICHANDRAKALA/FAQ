DROP PROCEDURE IF EXISTS sp_CreateTag;
DELIMITER $$
CREATE PROCEDURE sp_CreateTag(
    IN p_Name VARCHAR(100),
    IN p_CreatedBy BIGINT
)
BEGIN
    INSERT INTO tag (Name, CreatedBy, CreatedAt, UpdatedAt, IsActive)
    VALUES (p_Name, p_CreatedBy, NOW(), NOW(), 1);

    SELECT LAST_INSERT_ID() AS NewId;
END $$

DELIMITER ;