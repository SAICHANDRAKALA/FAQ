DROP PROCEDURE IF EXISTS sp_GetAllTags;
DELIMITER $$

CREATE PROCEDURE sp_GetAllTags(
    IN p_Page BIGINT,
    IN p_PageSize BIGINT,
    IN p_SearchKey VARCHAR(255)
)
BEGIN
    DECLARE offsetRows BIGINT;
    SET offsetRows = (GREATEST(p_Page,1)-1) * GREATEST(p_PageSize,1);

    SELECT
        q.Id,
        q.Name,
        totals.TotalCount AS TotalCount
    FROM
    (
        SELECT
            t.Id,
            t.Name
        FROM tag t
        WHERE t.IsActive = 1
          AND (p_SearchKey IS NULL OR TRIM(p_SearchKey) = '' 
               OR t.Name LIKE CONCAT('%', p_SearchKey, '%'))
        ORDER BY t.Name ASC
        LIMIT p_PageSize OFFSET offsetRows
    ) AS q
    CROSS JOIN
    (
        SELECT COUNT(*) AS TotalCount
        FROM tag t2
        WHERE t2.IsActive = 1
          AND (p_SearchKey IS NULL OR TRIM(p_SearchKey) = '' 
               OR t2.Name LIKE CONCAT('%', p_SearchKey, '%'))
    ) AS totals;
END $$

DELIMITER ;
