DROP PROCEDURE IF EXISTS sp_DeleteTag;
DELIMITER $$
CREATE PROCEDURE sp_DeleteTag(
    IN p_Id BIGINT,
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE tag
    SET IsActive = 0, UpdatedBy = p_UpdatedBy, UpdatedAt = NOW()
    WHERE Id = p_Id;
END $$
DELIMITER ;