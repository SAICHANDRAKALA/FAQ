DROP PROCEDURE IF EXISTS sp_UpdateTag;
DELIMITER $$
CREATE PROCEDURE sp_UpdateTag(
    IN p_Id BIGINT,
    IN p_Name VARCHAR(100),
    IN p_UpdatedBy BIGINT
)
BEGIN
    UPDATE tag
    SET
        Name = COALESCE(p_Name, Name),
        UpdatedBy = p_UpdatedBy,
        UpdatedAt = NOW()
    WHERE Id = p_Id
      AND IsActive = 1;
END $$
DELIMITER ;