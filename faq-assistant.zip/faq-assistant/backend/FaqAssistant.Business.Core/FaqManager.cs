using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Model;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.Business.Core
{
    public class FaqManager : IFaqManager
    {
        private readonly IFaqRepository _repo;
        private readonly IAiService _aiService;

        public FaqManager(IFaqRepository repo, IAiService aiService)
        {
            _repo = repo;
            _aiService = aiService;
        }

        public async Task<string> GetAiSuggestedAnswerAsync(string question, int maxTokens, float temperature)
        {
            return await _aiService.GetSuggestedAnswerAsync(question, maxTokens, temperature);
        }

        public PagedResult<Faq> GetAllFaqs(FaqSearchParamsDto searchParams)
        {
            // No validation/normalization here per request — repository handles queries
            return _repo.GetAllFaqs(searchParams);
        }

        public Faq? GetFaqById(long id) => _repo.GetFaqById(id);

        public long CreateFaq(FaqCreateDto dto)
        {
            var id = _repo.CreateFaq(dto);

            if (dto.TagIds != null && dto.TagIds.Any())
            {
                _repo.AddFaqTags(id, dto.TagIds, dto.CreatedBy);
            }

            return id;
        }

        public bool UpdateFaq(long id, FaqUpdateDto dto)
        {
            var ok = _repo.UpdateFaq(id, dto);

            if (ok && dto.TagIds != null)
            {
                _repo.AddFaqTags(id, dto.TagIds, dto.UpdatedBy);
            }

            return ok;
        }

        public bool DeleteFaq(long id, long deletedBy) => _repo.DeleteFaq(id, deletedBy);

        public bool AddTags(long faqId, List<long> tagIds, long userId) => _repo.AddFaqTags(faqId, tagIds, userId);

        public bool RemoveTag(long faqId, long tagId, long updatedBy) => _repo.RemoveFaqTag(faqId, tagId, updatedBy);
    }
}
