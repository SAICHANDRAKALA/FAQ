// Business/Core/TagManager.cs
using System.Collections.Generic;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Model.Tag;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.Business.Core
{
    public class TagManager : ITagManager
    {
        private readonly ITagRepository _repo;
        public TagManager(ITagRepository repo) { _repo = repo; }

        public PagedResult<Tag> GetAllTags(TagSearchParamsDto searchParams)
        {
            return _repo.GetAllTags(searchParams);
        }

        public Tag? GetTagById(long id) => _repo.GetTagById(id);

        public long CreateTag(TagCreateDto dto)
        {
            return _repo.CreateTag(dto);
        }

        public bool UpdateTag(long id, TagUpdateDto dto)
        {
            return _repo.UpdateTag(id, dto);
        }

        public bool DeleteTag(long id, long updatedBy)
        {
            return _repo.DeleteTag(id, updatedBy);
        }
    }
}
