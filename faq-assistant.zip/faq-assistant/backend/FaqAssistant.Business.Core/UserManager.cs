using FaqAssistant.Business.Core.Interface;
using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Model.User;
using Microsoft.AspNetCore.Identity;

namespace FaqAssistant.Business.Core
{
    public class UserManager : IUserManager
    {
        private readonly IUserRepository _repo;
        private readonly IPasswordHasher<User> _passwordHasher;

        public UserManager(IUserRepository repo, IPasswordHasher<User> passwordHasher)
        {
            _repo = repo;
            _passwordHasher = passwordHasher;
        }

        public long CreateUser(UserCreateDto dto)
        {
            // No validation here; rely on DTO DataAnnotations + ModelState + DB constraints
            var userForHash = new User
            {
                UserName = dto.UserName.Trim(),
                Email = dto.Email.Trim()
            };

            string passwordHash = _passwordHasher.HashPassword(userForHash, dto.Password);

            return _repo.CreateUser(userForHash.UserName, userForHash.Email, passwordHash, dto.CreatedBy);
        }

        public User? GetUserById(long id)
        {
            // Keep minimal guard to avoid repo calls with obviously invalid ids if you want; otherwise remove
            if (id <= 0) return null;
            return _repo.GetUserById(id);
        }

        public bool UpdateUser(long id, UserUpdateDto dto)
        {
            // No argument exceptions; manager is a thin pass-through.
            string? passwordHash = null;

            if (!string.IsNullOrWhiteSpace(dto.Password))
            {
                var existing = _repo.GetUserById(id);
                var userForHash = new User
                {
                    UserName = dto.UserName ?? existing?.UserName ?? string.Empty,
                    Email = dto.Email ?? existing?.Email ?? string.Empty
                };
                passwordHash = _passwordHasher.HashPassword(userForHash, dto.Password);
            }

            return _repo.UpdateUser(id,
                dto.UserName != null ? dto.UserName.Trim() : null,
                dto.Email != null ? dto.Email.Trim() : null,
                passwordHash,
                dto.UpdatedBy);
        }

        public bool DeleteUser(long id, long updatedBy)
        {
            // Pass-through
            return _repo.DeleteUser(id, updatedBy);
        }
    }
}
