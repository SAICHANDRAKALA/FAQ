using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.Extensions.Options;
using Microsoft.IdentityModel.Tokens;
using Microsoft.AspNetCore.Identity;

using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.Model.User;


namespace FaqAssistant.Business.Core
{
    public class AuthService : IAuthService
    {
        private readonly IUserRepository _repo;
        private readonly IPasswordHasher<User> _passwordHasher;
        private readonly JwtSettings _jwtSettings;

        public AuthService(IUserRepository repo, IPasswordHasher<User> passwordHasher, IOptions<JwtSettings> jwtOptions)
        {
            _repo = repo;
            _passwordHasher = passwordHasher;
            _jwtSettings = jwtOptions.Value;
        }

        public async Task<User?> ValidateCredentialsAsync(string username, string password)
        {
            // repo is sync; keep it sync if your repo is sync — wrapping in Task.FromResult for interface
            var user = _repo.GetUserByUsername(username);
            if (user == null) return null;
            var verification = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, password);
            if (verification == PasswordVerificationResult.Success || verification == PasswordVerificationResult.SuccessRehashNeeded)
            {
                return await Task.FromResult(user);
            }
            return null;
        }

        public string GenerateToken(User user)
        {
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwtSettings.Secret));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var claims = new List<Claim>
            {
                new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
                new Claim(JwtRegisteredClaimNames.UniqueName, user.UserName),
                new Claim("uid", user.Id.ToString()),
                new Claim("uname", user.UserName)
            };

            var expires = DateTime.UtcNow.AddMinutes(_jwtSettings.TokenLifetimeMinutes);

            var token = new JwtSecurityToken(
                issuer: _jwtSettings.Issuer,
                audience: _jwtSettings.Audience,
                claims: claims,
                expires: expires,
                signingCredentials: creds
            );

            return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
