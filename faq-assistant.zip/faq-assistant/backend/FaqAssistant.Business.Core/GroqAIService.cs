using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using FaqAssistant.Business.Core.Interface;

namespace FaqAssistant.Business.Core
{
    public class GroqAiService : IAiService
    {
        private readonly HttpClient _http;
        private readonly string _apiKey;
        private readonly string _model;
        private readonly string _endpoint;

        public GroqAiService(HttpClient http, IConfiguration config)
        {
            _http = http;
            _apiKey = config["Ai:ApiKey"] ?? throw new Exception("Groq API key missing");
            _model = config["Ai:Model"] ?? "llama-3.1-8b-instant";
            _endpoint = config["Ai:Endpoint"] ?? "https://api.groq.com/openai/v1/chat/completions";

            _http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _apiKey);
            _http.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
        }

        public async Task<string> GetSuggestedAnswerAsync(string question, int maxTokens = 256, float temperature = 0.2f)
        {
            if (string.IsNullOrWhiteSpace(question))
                throw new ArgumentException("question is required", nameof(question));

            // Defensive defaults / clamps
            if (maxTokens <= 0) maxTokens = 256;
            if (maxTokens > 8192) maxTokens = 8192;
            if (temperature < 0f) temperature = 0f;
            if (temperature > 2f) temperature = 1.0f;

            var payload = new
            {
                model = _model, // ensure this matches config
                messages = new[]
                {
            new { role = "system", content = "You are a concise helpful assistant that drafts knowledge-base answers for an internal FAQ. Keep answers short and actionable." },
            new { role = "user", content = question }
        },
                max_tokens = maxTokens,
                temperature = temperature,
                top_p = 1.0,
                n = 1
            };

            var body = JsonSerializer.Serialize(payload);
            using var request = new HttpRequestMessage(HttpMethod.Post, _endpoint)
            {
                Content = new StringContent(body, Encoding.UTF8, "application/json")
            };

            // Set header per-request (defensive)
            request.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Bearer", _apiKey);

            using var cts = new CancellationTokenSource(TimeSpan.FromSeconds(30));
            using var resp = await _http.SendAsync(request, cts.Token);
            var respBody = await resp.Content.ReadAsStringAsync(cts.Token);

            // If not successful, include status code + full response body so we can see provider error
            if (!resp.IsSuccessStatusCode)
            {
                throw new InvalidOperationException($"Groq API error {(int)resp.StatusCode} {resp.ReasonPhrase}: {respBody}");
            }

            // Parse success response (OpenAI/Groq style)
            try
            {
                using var doc = JsonDocument.Parse(respBody);
                var root = doc.RootElement;

                if (root.TryGetProperty("choices", out var choices) && choices.GetArrayLength() > 0)
                {
                    var first = choices[0];
                    if (first.TryGetProperty("message", out var message) && message.TryGetProperty("content", out var contentProp))
                        return contentProp.GetString() ?? string.Empty;

                    if (first.TryGetProperty("text", out var textProp))
                        return textProp.GetString() ?? string.Empty;
                }

                // If unexpected shape, return raw
                return respBody;
            }
            catch (JsonException)
            {
                return respBody;
            }
        }

    }
}
