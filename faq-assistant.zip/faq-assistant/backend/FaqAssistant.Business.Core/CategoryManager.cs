using System.Collections.Generic;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Model.Category;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.Business.Core
{
    public class CategoryManager : ICategoryManager
    {
        private readonly ICategoryRepository _repo;

        public CategoryManager(ICategoryRepository repo)
        {
            _repo = repo;
        }

        // Pass-through: forward DTO to repository
        public long CreateCategory(CategoryCreateDto dto)
        {
            return _repo.CreateCategory(dto);
        }

        public PagedResult<Category> GetAllCategories(CategorySearchParamsDto searchParams)
        {
            // forward the search DTO
            return _repo.GetAllCategories(searchParams);
        }

        public Category? GetCategoryById(long id)
        {
            return _repo.GetCategoryById(id);
        }

        // Pass-through: forward id + DTO to repository
        public bool UpdateCategory(long id, CategoryUpdateDto dto)
        {
            return _repo.UpdateCategory(id, dto);
        }

        public bool DeleteCategory(long id, long deletedBy)
        {
            return _repo.DeleteCategory(id, deletedBy);
        }
    }
}
