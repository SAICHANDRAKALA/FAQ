using System;
using System.Data;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Model;
using FaqAssistant.Model.Tag;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.DataAccess.Core
{
    public class TagRepository : ITagRepository
    {
        private readonly MySQLHelper _dbHelper;
        public TagRepository(MySQLHelper dbHelper) { _dbHelper = dbHelper; }

        public PagedResult<Tag> GetAllTags(TagSearchParamsDto searchParams)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Page", searchParams.Page),
                new MySqlParameter("p_PageSize", searchParams.PageSize),
                new MySqlParameter("p_SearchKey", string.IsNullOrWhiteSpace(searchParams.SearchKey) ? (object)DBNull.Value : searchParams.SearchKey)
            };

            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_GetAllTags", parameters);

            var paged = new PagedResult<Tag> { Page = searchParams.Page, PageSize = searchParams.PageSize };

            foreach (DataRow row in dt.Rows)
            {
                var t = new Tag
                {
                    Id = Convert.ToInt64(row["Id"]),
                    Name = row["Name"].ToString() ?? string.Empty
                };
                paged.Items.Add(t);
            }

            if (dt.Rows.Count > 0 && dt.Columns.Contains("TotalCount"))
                paged.Total = Convert.ToInt64(dt.Rows[0]["TotalCount"]);
            else
                paged.Total = paged.Items.Count;

            return paged;
        }

        public Tag? GetTagById(long id)
        {
            var parameters = new List<MySqlParameter> { new MySqlParameter("p_Id", id) };
            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_GetTagById", parameters);
            if (dt.Rows.Count == 0) return null;
            var r = dt.Rows[0];
            return new Tag
            {
                Id = Convert.ToInt64(r["Id"]),
                Name = r["Name"].ToString() ?? string.Empty
            };
        }

        public long CreateTag(TagCreateDto dto)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Name", dto.Name),
                new MySqlParameter("p_CreatedBy", dto.CreatedBy)
            };

            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_CreateTag", parameters);
            if (dt.Rows.Count > 0 && dt.Columns.Contains("NewId"))
                return Convert.ToInt64(dt.Rows[0]["NewId"]);
            return 0;
        }

        public bool UpdateTag(long id, TagUpdateDto dto)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Id", id),
                new MySqlParameter("p_Name", dto.Name ?? (object)DBNull.Value),
                new MySqlParameter("p_UpdatedBy", dto.UpdatedBy)
            };

            long rows = _dbHelper.ExecuteStoredProcedure<long>("sp_UpdateTag", parameters);
            return rows > 0;
        }

        public bool DeleteTag(long id, long updatedBy)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Id", id),
                new MySqlParameter("p_UpdatedBy", updatedBy)
            };

            long rows = _dbHelper.ExecuteStoredProcedure<long>("sp_DeleteTag", parameters);
            return rows > 0;
        }
    }
}
