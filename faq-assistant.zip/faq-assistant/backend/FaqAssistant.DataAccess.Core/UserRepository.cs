using System;
using System.Data;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Model.User;

namespace FaqAssistant.DataAccess.Core
{
    public class UserRepository : IUserRepository
    {
        private readonly MySQLHelper _dbHelper;
        public UserRepository(MySQLHelper dbHelper)
        {
            _dbHelper = dbHelper;
        }

        public long CreateUser(string userName, string email, string passwordHash, long createdBy)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_UserName", userName),
                new MySqlParameter("p_Email", email),
                new MySqlParameter("p_PasswordHash", passwordHash),
                new MySqlParameter("p_CreatedBy", createdBy)
            };

            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_CreateUser", parameters);
            if (dt.Rows.Count > 0 && dt.Columns.Contains("NewId"))
                return Convert.ToInt64(dt.Rows[0]["NewId"]);
            return 0;
        }

        public User? GetUserById(long id)
        {
            var parameters = new List<MySqlParameter> { new MySqlParameter("p_Id", id) };
            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_GetUserById", parameters);
            if (dt.Rows.Count == 0) return null;
            var r = dt.Rows[0];
            return new User
            {
                Id = Convert.ToInt64(r["Id"]),
                UserName = r["UserName"].ToString() ?? string.Empty
            };
        }

        public bool UpdateUser(long id, string? userName, string? email, string? passwordHash, long updatedBy)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Id", id),
                new MySqlParameter("p_UserName", userName ?? (object)DBNull.Value),
                new MySqlParameter("p_Email", email ?? (object)DBNull.Value),
                new MySqlParameter("p_PasswordHash", passwordHash ?? (object)DBNull.Value),
                new MySqlParameter("p_UpdatedBy", updatedBy)
            };

            long rows = _dbHelper.ExecuteStoredProcedure<long>("sp_UpdateUser", parameters);
            return rows > 0;
        }

        public bool DeleteUser(long id, long updatedBy)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Id", id),
                new MySqlParameter("p_UpdatedBy", updatedBy)
            };

            long rows = _dbHelper.ExecuteStoredProcedure<long>("sp_DeleteUser", parameters);
            return rows > 0;
        }

        public User? GetUserByUsername(string username)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_UserName", username)
            };
            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_GetUserByUsername", parameters);
            if (dt.Rows.Count == 0) return null;
            var r = dt.Rows[0];
            return new User
            {
                Id = Convert.ToInt64(r["Id"]),
                UserName = r["UserName"].ToString() ?? string.Empty,
                Email = r.Table.Columns.Contains("Email") ? r["Email"].ToString() ?? string.Empty : string.Empty,
                // store the DB column name for hashed password as "password_hash" earlier in schema
                PasswordHash = r.Table.Columns.Contains("password_hash") ? r["password_hash"].ToString() ?? string.Empty : string.Empty
            };
        }
    }
}
