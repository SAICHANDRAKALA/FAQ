using System;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Model;
using FaqAssistant.Model.Category;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.DataAccess.Core
{
    public class CategoryRepository : ICategoryRepository
    {
        private readonly MySQLHelper _dbHelper;
        public CategoryRepository(MySQLHelper dbHelper)
        {
            _dbHelper = dbHelper;
        }

        public PagedResult<Category> GetAllCategories(CategorySearchParamsDto searchParams)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Page", searchParams.Page),
                new MySqlParameter("p_PageSize", searchParams.PageSize),
                new MySqlParameter("p_SearchKey", string.IsNullOrWhiteSpace(searchParams.SearchKey) ? (object)DBNull.Value : searchParams.SearchKey)
            };

            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_GetAllCategories", parameters);

            var paged = new PagedResult<Category> { Page = searchParams.Page, PageSize = searchParams.PageSize };

            foreach (DataRow row in dt.Rows)
            {
                var cat = new Category
                {
                    Id = Convert.ToInt64(row["Id"]),
                    Name = row["Name"].ToString() ?? string.Empty,
                    Description = row["Description"] == DBNull.Value ? null : row["Description"].ToString()
                };
                paged.Items.Add(cat);
            }

            if (dt.Rows.Count > 0 && dt.Columns.Contains("TotalCount"))
                paged.Total = Convert.ToInt64(dt.Rows[0]["TotalCount"]);
            else
                paged.Total = paged.Items.Count;

            return paged;
        }

        public Category? GetCategoryById(long id)
        {
            var parameters = new List<MySqlParameter> { new MySqlParameter("p_Id", id) };
            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_GetCategoryById", parameters);
            if (dt.Rows.Count == 0) return null;
            var r = dt.Rows[0];
            return new Category
            {
                Id = Convert.ToInt64(r["Id"]),
                Name = r["Name"].ToString() ?? string.Empty,
                Description = r["Description"] == DBNull.Value ? null : r["Description"].ToString()
            };
        }

        public long CreateCategory(CategoryCreateDto dto)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Name", dto.Name),
                new MySqlParameter("p_Description", dto.Description ?? (object)DBNull.Value),
                new MySqlParameter("p_CreatedBy", dto.CreatedBy)
            };

            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_CreateCategory", parameters);
            if (dt.Rows.Count > 0 && dt.Columns.Contains("NewId"))
                return Convert.ToInt64(dt.Rows[0]["NewId"]);
            return 0;
        }

        public bool UpdateCategory(long id, CategoryUpdateDto dto)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Id", id),
                new MySqlParameter("p_Name", dto.Name ?? (object)DBNull.Value),
                new MySqlParameter("p_Description", dto.Description ?? (object)DBNull.Value),
                new MySqlParameter("p_UpdatedBy", dto.UpdatedBy)
            };

            long rows = _dbHelper.ExecuteStoredProcedure<long>("sp_UpdateCategory", parameters);
            return rows > 0;
        }

        public bool DeleteCategory(long id, long updatedBy)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Id", id),
                new MySqlParameter("p_UpdatedBy", updatedBy)
            };

            long rows = _dbHelper.ExecuteStoredProcedure<long>("sp_DeleteCategory", parameters);
            return rows > 0;
        }
    }
}
