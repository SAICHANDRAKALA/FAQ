using System.Data;
using MySql.Data.MySqlClient;
using System.Collections.Generic;

namespace FaqAssistant.DataAccess.Core
{

    public class MySQLHelper
    {
        private readonly string _connectionString;
        public MySQLHelper(string connectionString)
        {
            _connectionString = connectionString;
        }

        public DataTable ExecuteQuery(string query)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand(query, connection);
                var dataTable = new DataTable();
                using (var reader = command.ExecuteReader())
                {
                    dataTable.Load(reader);
                }
                return dataTable;
            }
        }

        public int ExecuteNonQuery(string query)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand(query, connection);
                return command.ExecuteNonQuery();
            }
        }

        public object ExecuteScalar(string query)
        {
            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();
                var command = new MySqlCommand(query, connection);
                return command.ExecuteScalar();
            }
        }
        public T ExecuteStoredProcedure<T>(string storedProcedureName, List<MySqlParameter> parameters = null) where T : new()
        {
            if (string.IsNullOrEmpty(_connectionString))
                throw new InvalidOperationException("Connection string cannot be null or empty.");

            using (var connection = new MySqlConnection(_connectionString))
            {
                connection.Open();

                using (var command = new MySqlCommand(storedProcedureName, connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.CommandTimeout = 30;

                    parameters ??= new List<MySqlParameter>();
                    foreach (var parameter in parameters)
                    {
                        command.Parameters.Add(parameter);
                    }

                    if (typeof(T) == typeof(DataTable))
                    {
                        var dataTable = new DataTable();
                        using (var reader = command.ExecuteReader())
                        {
                            dataTable.Load(reader);
                        }
                        return (T)(object)dataTable;
                    }
                    else if (typeof(T) == typeof(int))
                    {
                        int rowsAffected = command.ExecuteNonQuery();
                        return (T)(object)rowsAffected;
                    }
                    else if (typeof(T) == typeof(long))
                    {
                        long rowsAffected = command.ExecuteNonQuery();
                        return (T)(object)rowsAffected;
                    }
                    else if (typeof(T) == typeof(object))
                    {
                        var result = command.ExecuteScalar();
                        return (T)(object)result;
                    }
                    else
                    {
                        using (var reader = command.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                var result = new T();
                                foreach (var prop in typeof(T).GetProperties())
                                {
                                    if (!reader.IsDBNull(reader.GetOrdinal(prop.Name)))
                                    {
                                        prop.SetValue(result, reader[prop.Name]);
                                    }
                                }
                                return result;
                            }
                            return default;
                        }
                    }
                }
            }
        }

        public MySqlDataReader ExecuteStoredProcedureReader(string storedProcedureName, List<MySqlParameter> parameters)
        {
            var connection = new MySqlConnection(_connectionString);
            var command = new MySqlCommand(storedProcedureName, connection)
            {
                CommandType = CommandType.StoredProcedure
            };
            command.Parameters.AddRange(parameters.ToArray());
            connection.Open();
            return command.ExecuteReader(CommandBehavior.CloseConnection);
        }
    }
}