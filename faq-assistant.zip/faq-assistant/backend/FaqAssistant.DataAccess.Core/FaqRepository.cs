using System;
using System.Data;
using System.Linq;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Model;
using FaqAssistant.Model.Faq;
using System.Collections.Generic;
using MySql.Data.MySqlClient;
using Newtonsoft.Json;

namespace FaqAssistant.DataAccess.Core
{
    public class FaqRepository : IFaqRepository
    {
        private readonly MySQLHelper _dbHelper;

        public FaqRepository(MySQLHelper dbHelper)
        {
            _dbHelper = dbHelper ?? throw new ArgumentNullException(nameof(dbHelper));
        }

        public PagedResult<Faq> GetAllFaqs(FaqSearchParamsDto searchParams)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_CategoryId", searchParams.CategoryId ?? 0),
                new MySqlParameter("p_Tag", string.IsNullOrWhiteSpace(searchParams.Tag) ? (object)DBNull.Value : searchParams.Tag),
                new MySqlParameter("p_Keyword", string.IsNullOrWhiteSpace(searchParams.Keyword) ? (object)DBNull.Value : searchParams.Keyword),
                new MySqlParameter("p_Page", searchParams.Page),
                new MySqlParameter("p_PageSize", searchParams.PageSize)
            };

            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_GetAllFaqs", parameters);

            var paged = new PagedResult<Faq> { Page = searchParams.Page, PageSize = searchParams.PageSize };

            foreach (DataRow row in dt.Rows)
            {
                var faq = new Faq
                {
                    Id = Convert.ToInt64(row["Id"]),
                    Question = row.Table.Columns.Contains("Question") ? row["Question"].ToString()! : row["Question"].ToString()!,
                    Answer = row["Answer"] == DBNull.Value ? null : row["Answer"].ToString(),
                    CategoryId = Convert.ToInt64(row["CategoryId"])
                };

                if (dt.Columns.Contains("Tags") && row["Tags"] != DBNull.Value)
                {
                    var tagNames = row["Tags"].ToString()!
                        .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
                }

                paged.Items.Add(faq);
            }

            if (dt.Rows.Count > 0 && dt.Columns.Contains("TotalCount"))
                paged.Total = Convert.ToInt64(dt.Rows[0]["TotalCount"]);
            else
                paged.Total = paged.Items.Count;

            return paged;
        }

        public Faq? GetFaqById(long id)
        {
            var parameters = new List<MySqlParameter> { new MySqlParameter("p_Id", id) };
            DataTable dt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_GetFaqById", parameters);
            if (dt.Rows.Count == 0) return null;

            var row = dt.Rows[0];
            var faq = new Faq
            {
                Id = Convert.ToInt64(row["Id"]),
                Question = row.Table.Columns.Contains("Question") ? row["Question"].ToString()! : row["Question"].ToString()!,
                Answer = row["Answer"] == DBNull.Value ? null : row["Answer"].ToString(),
                CategoryId = Convert.ToInt64(row["CategoryId"])
            };

            if (dt.Columns.Contains("Tags") && row["Tags"] != DBNull.Value)
            {
                var tagNames = row["Tags"].ToString()!
                    .Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            }

            return faq;
        }

        public long CreateFaq(FaqCreateDto dto)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Question", dto.Question),
                new MySqlParameter("p_Answer", dto.Answer ?? (object)DBNull.Value),
                new MySqlParameter("p_CategoryId", dto.CategoryId),
                new MySqlParameter("p_CreatedBy", dto.CreatedBy)
            };

            DataTable idDt = _dbHelper.ExecuteStoredProcedure<DataTable>("sp_CreateFaq", parameters);

            if (idDt != null && idDt.Rows.Count > 0 && idDt.Columns.Contains("NewId"))
            {
                return Convert.ToInt64(idDt.Rows[0]["NewId"]);
            }

            return 0;
        }


        public bool UpdateFaq(long id, FaqUpdateDto dto)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_Id", id),
                new MySqlParameter("p_Question", dto.Question ?? (object)DBNull.Value),
                new MySqlParameter("p_Answer", dto.Answer ?? (object)DBNull.Value),
                new MySqlParameter("p_CategoryId", dto.CategoryId ?? (object)DBNull.Value),
                new MySqlParameter("p_UpdatedBy", dto.UpdatedBy)
            };

            long rowsAffected = _dbHelper.ExecuteStoredProcedure<long>("sp_UpdateFaq", parameters);

            if (dto.TagIds != null)
            {
                _ = _dbHelper.ExecuteStoredProcedure<long>("sp_RemoveAllTagsFromFaq", 
                new List<MySqlParameter> { new MySqlParameter("p_FaqId", id), new MySqlParameter("p_UpdatedBy", dto.UpdatedBy) });

                AddFaqTags(id, dto.TagIds, dto.UpdatedBy);
            }

            return rowsAffected > 0;
        }

        public bool DeleteFaq(long id, long deletedBy)
        {
            var parameters = new List<MySqlParameter> { 
                new MySqlParameter("p_Id", id),
                new MySqlParameter("p_UpdatedBy", deletedBy)
                 };
            long rowsAffected = _dbHelper.ExecuteStoredProcedure<long>("sp_DeleteFaq", parameters);
            return rowsAffected > 0;
        }


        public bool AddFaqTags(long faqId, List<long> tagIds, long userId)
        {
            string tagIdsJson = JsonConvert.SerializeObject(tagIds);

            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_FaqId", faqId),
                new MySqlParameter("p_TagIdsJson", tagIdsJson),
                new MySqlParameter("p_UserId", userId)
            };

            long rowsAffected = _dbHelper.ExecuteStoredProcedure<long>("sp_AddFaqTagsJson", parameters);

            return true;
        }


        public bool RemoveFaqTag(long faqId, long tagId, long updatedBy)
        {
            var parameters = new List<MySqlParameter>
            {
                new MySqlParameter("p_FaqId", faqId),
                new MySqlParameter("p_TagId", tagId),
                new MySqlParameter("p_UpdatedBy", updatedBy)
            };

            long rowsAffected = _dbHelper.ExecuteStoredProcedure<long>("sp_RemoveFaqTag", parameters);
            return rowsAffected > 0;
        }
    }
}
