using System.Threading.Tasks;

namespace FaqAssistant.Business.Core.Interface
{
    public interface IAiService
    {
        Task<string> GetSuggestedAnswerAsync(string question, int maxTokens, float temperature);
    }
}
