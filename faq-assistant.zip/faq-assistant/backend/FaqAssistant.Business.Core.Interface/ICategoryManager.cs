using FaqAssistant.Model;
using FaqAssistant.Model.Category;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.Business.Core.Interface
{
    public interface ICategoryManager
    {
        PagedResult<Category> GetAllCategories(CategorySearchParamsDto searchParams);
        Category? GetCategoryById(long id);
        long CreateCategory(CategoryCreateDto dto);
        bool UpdateCategory(long id, CategoryUpdateDto dto);
        bool DeleteCategory(long id, long updatedBy);
    }
}