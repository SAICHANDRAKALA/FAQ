using System;
using System.Collections.Generic;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.Business.Core.Interface
{
    public interface IFaqManager
    {
        PagedResult<Faq> GetAllFaqs(FaqSearchParamsDto searchParams);
        Faq? GetFaqById(long id);
        long CreateFaq(FaqCreateDto dto);
        bool UpdateFaq(long id, FaqUpdateDto dto);
        bool DeleteFaq(long id, long deletedBy);
        bool AddTags(long faqId, List<long> tagIds, long userId);
        bool RemoveTag(long faqId, long tagId, long updatedBy);
        Task<string> GetAiSuggestedAnswerAsync(string question, int maxTokens, float temperature);

    }
}