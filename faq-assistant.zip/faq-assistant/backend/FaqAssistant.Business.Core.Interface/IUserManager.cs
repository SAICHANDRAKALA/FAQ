using FaqAssistant.Model;
using FaqAssistant.Model.User;

namespace FaqAssistant.Business.Core.Interface
{
    public interface IUserManager
    {
        User? GetUserById(long id);
        long CreateUser(UserCreateDto dto);
        bool UpdateUser(long id, UserUpdateDto dto);
        bool DeleteUser(long id, long updatedBy);
    }
}