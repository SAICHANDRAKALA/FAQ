using FaqAssistant.Model.User;

namespace FaqAssistant.Business.Core.Interface
{
    public interface IAuthService
    {
        // Validate username + password; return user if valid, otherwise null
        Task<User?> ValidateCredentialsAsync(string username, string password);

        // Create JWT for a user
        string GenerateToken(User user);
    }
}
