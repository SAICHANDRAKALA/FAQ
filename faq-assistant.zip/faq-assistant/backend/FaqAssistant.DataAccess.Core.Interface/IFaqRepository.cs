using System;
using System.Collections.Generic;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.DataAccess.Core.Interface
{
    public interface IFaqRepository
    {
        PagedResult<Faq> GetAllFaqs(FaqSearchParamsDto searchParams);
        Faq? GetFaqById(long id);
        long CreateFaq(FaqCreateDto dto);
        bool UpdateFaq(long id, FaqUpdateDto dto);
        bool DeleteFaq(long id, long deletedBy);
        bool AddFaqTags(long faqId, List<long> tagIds, long userId);
        bool RemoveFaqTag(long faqId, long tagId, long updatedBy);
    }
}