using FaqAssistant.Model;
using FaqAssistant.Model.User;

namespace FaqAssistant.DataAccess.Core.Interface
{
    public interface IUserRepository
    {
        User? GetUserById(long id);
        long CreateUser(string userName, string email, string passwordHash, long createdBy);
        bool UpdateUser(long id, string? userName, string? email, string? passwordHash, long updatedBy);
        bool DeleteUser(long id, long updatedBy);
        User? GetUserByUsername(string username);
    }
}