using FaqAssistant.Model;
using FaqAssistant.Model.Tag;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.DataAccess.Core.Interface
{
    public interface ITagRepository
    {
        PagedResult<Tag> GetAllTags(TagSearchParamsDto searchParams);
        Tag? GetTagById(long id);
        long CreateTag(TagCreateDto dto);
        bool UpdateTag(long id, TagUpdateDto dto);
        bool DeleteTag(long id, long updatedBy);
    }
}