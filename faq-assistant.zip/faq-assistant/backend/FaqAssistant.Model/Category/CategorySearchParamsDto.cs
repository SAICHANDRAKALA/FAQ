namespace FaqAssistant.Model.Category
{
    public class CategorySearchParamsDto
    {
        public long Page { get; set; } = 1;
        public long PageSize { get; set; } = 20;
        public string? SearchKey { get; set; }
    }
}