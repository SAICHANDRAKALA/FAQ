// Models/Category/CategoryCreateDto.cs
using System.ComponentModel.DataAnnotations;

namespace FaqAssistant.Model.Category
{
    public class CategoryCreateDto
    {
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(100, MinimumLength = 1, ErrorMessage = "Name must be between 1 and 100 characters.")]
        public string Name { get; set; } = null!;

        [StringLength(255, ErrorMessage = "Description cannot exceed 255 characters.")]
        public string? Description { get; set; }

        [Required(ErrorMessage = "CreatedBy is required.")]
        [Range(1, long.MaxValue, ErrorMessage = "CreatedBy must be a valid user id.")]
        public long CreatedBy { get; set; }
    }
}
