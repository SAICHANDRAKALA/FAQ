namespace FaqAssistant.Model.Faq
{
    public class AiSuggestionResponseDto
    {
        public string SuggestedAnswer { get; set; } = string.Empty;
    }
}