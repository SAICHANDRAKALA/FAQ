// Models/Dto/FaqUpdateDto.cs
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FaqAssistant.Model.Faq
{
    public class FaqUpdateDto
    {
        // optional on update; if present must be >= 5 chars
        [MinLength(5, ErrorMessage = "Question must be at least 5 characters long.")]
        [StringLength(1000, ErrorMessage = "Question cannot exceed 1000 characters.")]
        public string? Question { get; set; }

        [StringLength(4000, ErrorMessage = "Answer cannot exceed 4000 characters.")]
        public string? Answer { get; set; }

        // optional; if provided must be valid id
        [Range(1, long.MaxValue, ErrorMessage = "CategoryId must be a valid ID.")]
        public long? CategoryId { get; set; }

        public List<long>? TagIds { get; set; }

        // If you require UpdatedBy for every update, mark Required
        [Required(ErrorMessage = "UpdatedBy is required.")]
        [Range(1, long.MaxValue, ErrorMessage = "UpdatedBy must be a valid user id.")]
        public long UpdatedBy { get; set; }
    }
}
