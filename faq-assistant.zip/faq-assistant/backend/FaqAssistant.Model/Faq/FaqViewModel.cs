using System.Collections.Generic;

namespace FaqAssistant.Model.Faq
{
    public class FaqViewModel
    {
        public long RecordCount { get; set; }
        public List<Faq> Faqs { get; set; } = new List<Faq>();
    }
}