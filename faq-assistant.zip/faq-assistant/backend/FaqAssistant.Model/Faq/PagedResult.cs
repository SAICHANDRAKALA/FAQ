

// Models/PagedResult.cs
namespace FaqAssistant.Model.Faq
{
    public class PagedResult<T>
    {
        public long Page { get; set; }
        public long PageSize { get; set; }
        public long Total { get; set; }
        public List<T> Items { get; set; } = new List<T>();
    }
}