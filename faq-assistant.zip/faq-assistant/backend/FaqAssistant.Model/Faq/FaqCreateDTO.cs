// Models/Dto/FaqCreateDto.cs
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace FaqAssistant.Model.Faq
{
    public class FaqCreateDto
    {
        [Required(ErrorMessage = "Question is required.")]
        [MinLength(5, ErrorMessage = "Question must be at least 5 characters long.")]
        [StringLength(1000, ErrorMessage = "Question cannot exceed 1000 characters.")]
        public string Question { get; set; } = null!;

        [StringLength(4000, ErrorMessage = "Answer cannot exceed 4000 characters.")]
        public string? Answer { get; set; }

        [Range(1, long.MaxValue, ErrorMessage = "CategoryId is required.")]
        public long CategoryId { get; set; }

        // optional tags
        public List<long>? TagIds { get; set; }

        [Range(1, long.MaxValue, ErrorMessage = "CreatedBy is required.")]
        public long CreatedBy { get; set; }
    }
}
