// Models/Dto/FaqSearchParamsDto.cs
namespace FaqAssistant.Model.Faq
{
    public class FaqSearchParamsDto
    {
        public long? CategoryId { get; set; }
        public string? Tag { get; set; }
        public string? Keyword { get; set; }

        // Use int if you prefer; validated in controller/manager
        public long Page { get; set; } = 1;
        public long PageSize { get; set; } = 20;
    }
}
