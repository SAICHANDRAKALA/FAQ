// Models/Dto/AiSuggestionRequestDto.cs
using System.ComponentModel.DataAnnotations;

namespace FaqAssistant.Model.Faq
{
    public class AiSuggestionRequestDto
    {
        [Required(ErrorMessage = "Question is required.")]
        [MinLength(5, ErrorMessage = "Question must be at least 5 characters long.")]
        [StringLength(2000, ErrorMessage = "Question cannot exceed 2000 characters.")]
        public string Question { get; set; } = null!;

        // sensible default; validate range if needed
        [Range(1, 2048, ErrorMessage = "MaxTokens must be between 1 and 2048.")]
        public int MaxTokens { get; set; } = 250;

        // optional; you can validate range [0..2]
        [Range(0.0, 2.0, ErrorMessage = "Temperature must be between 0.0 and 2.0.")]
        public float? Temperature { get; set; }
    }
}
