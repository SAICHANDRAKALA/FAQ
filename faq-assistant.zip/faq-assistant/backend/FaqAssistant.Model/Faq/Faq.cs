// Models/Faq.cs
using System;

namespace FaqAssistant.Model.Faq
{
    public class Faq
    {
        public long Id { get; set; }

        // Keep non-nullable if DB requires it; Add max length to protect DB
        public string Question { get; set; } = null!;

        // Answer can be null
        public string? Answer { get; set; }

        public long CategoryId { get; set; }
    }
}
