using System.ComponentModel.DataAnnotations;

namespace FaqAssistant.Model.User
{
    public class UserCreateDto
    {
        [Required(ErrorMessage = "UserName is required.")]
        [StringLength(200, ErrorMessage = "UserName cannot exceed 200 characters.")]
        public string UserName { get; set; } = null!;

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Email is not valid.")]
        [StringLength(320, ErrorMessage = "Email cannot exceed 320 characters.")]
        public string Email { get; set; } = null!;

        [Required(ErrorMessage = "Password is required.")]
        [MinLength(6, ErrorMessage = "Password must be at least 6 characters long.")]
        public string Password { get; set; } = null!;

        [Range(1, long.MaxValue, ErrorMessage = "CreatedBy is required.")]
        public long CreatedBy { get; set; }
    }
}
