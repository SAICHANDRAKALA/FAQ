using System;
using System.ComponentModel.DataAnnotations;

namespace FaqAssistant.Model.User
{
    public class User
    {
        public long Id { get; set; }

        [Required(ErrorMessage = "UserName is required.")]
        [StringLength(200, ErrorMessage = "UserName cannot exceed 200 characters.")]
        public string UserName { get; set; } = null!;

        [Required(ErrorMessage = "Email is required.")]
        [EmailAddress(ErrorMessage = "Email is not a valid email address.")]
        [StringLength(320, ErrorMessage = "Email cannot exceed 320 characters.")]
        public string Email { get; set; } = null!;
        public string PasswordHash { get; set; } = "";
        public bool IsActive { get; set; } = true;
    }
}
