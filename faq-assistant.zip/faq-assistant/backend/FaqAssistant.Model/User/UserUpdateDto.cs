using System.ComponentModel.DataAnnotations;

namespace FaqAssistant.Model.User
{
    public class UserUpdateDto
    {
        [StringLength(200, ErrorMessage = "UserName cannot exceed 200 characters.")]
        public string? UserName { get; set; }

        [EmailAddress(ErrorMessage = "Email is not valid.")]
        [StringLength(320, ErrorMessage = "Email cannot exceed 320 characters.")]
        public string? Email { get; set; }

        [MinLength(6, ErrorMessage = "Password must be at least 6 characters long.")]
        public string? Password { get; set; }

        [Required(ErrorMessage = "UpdatedBy is required.")]
        [Range(1, long.MaxValue, ErrorMessage = "UpdatedBy must be a valid user id.")]
        public long UpdatedBy { get; set; }
    }
}
