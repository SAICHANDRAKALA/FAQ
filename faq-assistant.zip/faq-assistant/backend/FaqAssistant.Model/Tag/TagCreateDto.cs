// Models/Tag/TagCreateDto.cs
using System.ComponentModel.DataAnnotations;

namespace FaqAssistant.Model.Tag
{
    public class TagCreateDto
    {
        [Required(ErrorMessage = "Name is required.")]
        [StringLength(200, ErrorMessage = "Name cannot exceed 200 characters.")]
        public string Name { get; set; } = null!;

        [Range(1, long.MaxValue, ErrorMessage = "CreatedBy is required.")]
        public long CreatedBy { get; set; }
    }
}
