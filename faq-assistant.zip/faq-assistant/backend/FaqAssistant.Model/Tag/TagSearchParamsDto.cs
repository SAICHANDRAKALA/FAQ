namespace FaqAssistant.Model.Tag
{
    public class TagSearchParamsDto
    {
        public long Page { get; set; } = 1;
        public long PageSize { get; set; } = 50;
        public string? SearchKey { get; set; } 
    }
}