// Models/Tag/TagUpdateDto.cs
using System.ComponentModel.DataAnnotations;

namespace FaqAssistant.Model.Tag
{
    public class TagUpdateDto
    {
        [StringLength(200, ErrorMessage = "Name cannot exceed 200 characters.")]
        public string? Name { get; set; }

        [Required(ErrorMessage = "UpdatedBy is required.")]
        [Range(1, long.MaxValue, ErrorMessage = "UpdatedBy must be a valid user id.")]
        public long UpdatedBy { get; set; }
    }
}
