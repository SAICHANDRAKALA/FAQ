using System;
using System.Diagnostics;
using System.Net;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.Model;
using FaqAssistant.Model.Faq;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Authorization;

namespace FaqAssistant.Api.Controllers
{
    [Authorize]
    [ApiController]
    [Route("api/[controller]")]
    public class FaqController : ControllerBase
    {
        private readonly IFaqManager _manager;
        public FaqController(IFaqManager manager)
        {
            _manager = manager;
        }
        
        public class ApiResponse<T>
        {
            public int Code { get; set; }
            public bool Success { get; set; }
            public IEnumerable<string> Messages { get; set; }
            public T Data { get; set; }

            public static ApiResponse<T> SuccessResponse(T data, string message = null, int code = 200)
                => new ApiResponse<T> { Code = code, Success = true, Messages = message == null ? Array.Empty<string>() : new[] { message }, Data = data };

            public static ApiResponse<T> FailureResponse(IEnumerable<string> messages, int code = 400)
                => new ApiResponse<T> { Code = code, Success = false, Messages = messages ?? Array.Empty<string>(), Data = default };

            public static ApiResponse<T> FailureResponse(string message, int code = 400)
                => FailureResponse(new[] { message }, code);
        }

        private IActionResult BuildActionResult<T>(ApiResponse<T> response)
        {
            return StatusCode(response.Code, response);
        }

        [HttpPost]
        [Route("list")]
        [ResponseCache(NoStore = true)]
        public IActionResult GetAll([FromBody] FaqSearchParamsDto searchParams)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                if (searchParams == null)
                    return BuildActionResult(ApiResponse<PagedResult<Faq>>.FailureResponse("Request body is required.", (int)HttpStatusCode.BadRequest));

                var result = _manager.GetAllFaqs(searchParams) ?? new PagedResult<Faq>();

                if (result.Items != null && result.Items.Count > 0)
                {
                    return BuildActionResult(ApiResponse<PagedResult<Faq>>.SuccessResponse(result, "FAQs fetched successfully.", (int)HttpStatusCode.OK));
                }

                return BuildActionResult(ApiResponse<PagedResult<Faq>>.SuccessResponse(result, "No FAQs found.", (int)HttpStatusCode.OK));
            }
            catch (Exception ex)
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
            finally
            {
                timer.Stop();
            }
        }

        [HttpGet("{id:long}")]
        [ResponseCache(NoStore = true)]
        public IActionResult Get([FromRoute][Range(1, long.MaxValue)] long id)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                if (id <= 0)
                {
                    return BuildActionResult(ApiResponse<object>.FailureResponse("Invalid request. Id must be greater than zero.", (int)HttpStatusCode.BadRequest));
                }

                var faq = _manager.GetFaqById(id);
                if (faq != null)
                {
                    return BuildActionResult(ApiResponse<Faq>.SuccessResponse(faq, "FAQ fetched successfully.", (int)HttpStatusCode.OK));
                }

                return BuildActionResult(ApiResponse<Faq>.FailureResponse("FAQ not found.", (int)HttpStatusCode.NotFound));
            }
            catch (Exception ex)
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
            finally
            {
                timer.Stop();
            }
        }

        [HttpPost]
        [ResponseCache(NoStore = true)]
        public IActionResult Create([FromBody] FaqCreateDto dto)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                if (dto == null)
                    return BuildActionResult(ApiResponse<object>.FailureResponse("Request body is required.", (int)HttpStatusCode.BadRequest));

                var newId = _manager.CreateFaq(dto);
                if (newId > 0)
                {
                    return BuildActionResult(ApiResponse<object>.SuccessResponse(new { id = newId }, "FAQ created successfully.", (int)HttpStatusCode.Created));
                }

                return BuildActionResult(ApiResponse<object>.FailureResponse("Failed to create FAQ.", (int)HttpStatusCode.InternalServerError));
            }
            catch (Exception ex)
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
            finally
            {
                timer.Stop();
            }
        }

        [HttpPut("{id:long}")]
        [ResponseCache(NoStore = true)]
        public IActionResult Update([FromRoute][Range(1, long.MaxValue)] long id, [FromBody] FaqUpdateDto dto)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                if (id <= 0 || dto == null)
                    return BuildActionResult(ApiResponse<object>.FailureResponse("Invalid request.", (int)HttpStatusCode.BadRequest));

                var ok = _manager.UpdateFaq(id, dto);
                if (ok)
                {
                    return BuildActionResult(ApiResponse<object>.SuccessResponse(null, "FAQ updated successfully.", (int)HttpStatusCode.OK));
                }

                return BuildActionResult(ApiResponse<object>.FailureResponse("No FAQ found to update.", (int)HttpStatusCode.NotFound));
            }
            catch
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
            finally
            {
                timer.Stop();
            }
        }

        [HttpDelete("{id:long}")]
        [ResponseCache(NoStore = true)]
        public IActionResult Delete([FromRoute][Range(1, long.MaxValue)] long id, [FromQuery] long deletedBy = 0)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                if (id <= 0)
                    return BuildActionResult(ApiResponse<object>.FailureResponse("Invalid request.", (int)HttpStatusCode.BadRequest));

                var ok = _manager.DeleteFaq(id, deletedBy);
                if (ok)
                {
                    return BuildActionResult(ApiResponse<object>.SuccessResponse(null, "FAQ deleted successfully.", (int)HttpStatusCode.OK));
                }

                return BuildActionResult(ApiResponse<object>.FailureResponse("No FAQ found to delete.", (int)HttpStatusCode.NotFound));
            }
            catch (Exception ex)
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
            finally
            {
                timer.Stop();
            }
        }

        [HttpPost("{id:long}/tags")]
        [ResponseCache(NoStore = true)]
        public IActionResult AddTags(
            [FromRoute][Range(1, long.MaxValue)] long id,
            [FromBody][Required][MinLength(1, ErrorMessage = "At least one TagId is required.")] List<long> tagIds,
            [FromQuery][Range(1, long.MaxValue, ErrorMessage = "userId is required.")] long userId)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                if (id <= 0)
                    return BuildActionResult(ApiResponse<object>.FailureResponse("Invalid FAQ id.", (int)HttpStatusCode.BadRequest));

                if (tagIds == null || tagIds.Count == 0)
                    return BuildActionResult(ApiResponse<object>.FailureResponse("At least one TagId is required.", (int)HttpStatusCode.BadRequest));

                var ok = _manager.AddTags(id, tagIds, userId);
                if (ok)
                {
                    return BuildActionResult(ApiResponse<object>.SuccessResponse(null, "Tags added successfully.", (int)HttpStatusCode.OK));
                }

                return BuildActionResult(ApiResponse<object>.FailureResponse("Failed to add tags.", (int)HttpStatusCode.InternalServerError));
            }
            catch (Exception ex)
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
            finally
            {
                timer.Stop();
            }
        }

        [HttpDelete("{id:long}/tags/{tagId:long}")]
        [ResponseCache(NoStore = true)]
        public IActionResult RemoveTag(
            [FromRoute][Range(1, long.MaxValue)] long id,
            [FromRoute][Range(1, long.MaxValue)] long tagId,
            long updatedBy)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                if (id <= 0 || tagId <= 0)
                    return BuildActionResult(ApiResponse<object>.FailureResponse("Invalid request.", (int)HttpStatusCode.BadRequest));

                var ok = _manager.RemoveTag(id, tagId, updatedBy);
                if (ok)
                {
                    return BuildActionResult(ApiResponse<object>.SuccessResponse(null, "Tag removed successfully.", (int)HttpStatusCode.OK));
                }

                return BuildActionResult(ApiResponse<object>.FailureResponse("No tag mapping found to remove.", (int)HttpStatusCode.NotFound));
            }
            catch (Exception ex)
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
            finally
            {
                timer.Stop();
            }
        }

        [HttpPost]
        [Route("suggest")]
        [ResponseCache(NoStore = true)]
        public async Task<IActionResult> SuggestAnswer([FromBody] AiSuggestionRequestDto req)
        {
            var timer = System.Diagnostics.Stopwatch.StartNew();

            try
            {
                if (req == null || string.IsNullOrWhiteSpace(req.Question))
                    return BuildActionResult(ApiResponse<object>.FailureResponse("Question is required.", (int)HttpStatusCode.BadRequest));

                string answer = await _manager.GetAiSuggestedAnswerAsync(
                    req.Question,
                    req.MaxTokens,
                    req.Temperature ?? 0.7f
                );

                return BuildActionResult(ApiResponse<AiSuggestionResponseDto>.SuccessResponse(new AiSuggestionResponseDto { SuggestedAnswer = answer }, "Suggested answer generated successfully.", (int)HttpStatusCode.OK));
            }
            catch (Exception ex)
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
            finally
            {
                timer.Stop();
            }
        }
    }
}
