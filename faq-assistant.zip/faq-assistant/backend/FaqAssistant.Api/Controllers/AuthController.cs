// AuthController.cs
using Microsoft.AspNetCore.Mvc;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.Model.User;

namespace FaqAssistant.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly IAuthService _authService;
        private readonly IUserManager _userManager;

        public record LoginRequest(string Username, string Password);
        public record AuthResponse(string Token, DateTime ExpiresAt);

        public AuthController(IAuthService authService, IUserManager userManager)
        {
            _authService = authService;
            _userManager = userManager;
        }

        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginRequest req)
        {
            if (string.IsNullOrWhiteSpace(req.Username) || string.IsNullOrWhiteSpace(req.Password))
                return BadRequest(new { message = "Username and password required." });

            var user = await _authService.ValidateCredentialsAsync(req.Username.Trim(), req.Password);
            if (user == null)
                return Unauthorized(new { message = "Invalid username or password." });

            var token = _authService.GenerateToken(user);
            var handler = new System.IdentityModel.Tokens.Jwt.JwtSecurityTokenHandler();
            var jwt = handler.ReadJwtToken(token);
            return Ok(new AuthResponse(token, jwt.ValidTo));
        }

        // Optional registration using your existing manager (assuming UserCreateDto exists)
        [HttpPost("register")]
        public IActionResult Register([FromBody] UserCreateDto dto)
        {
            if (dto == null) return BadRequest();
            // let your existing manager handle creation and hashing
            var id = _userManager.CreateUser(dto);
            if (id > 0) return Created($"/api/users/{id}", new { id });
            return StatusCode(500, new { message = "Failed to create user" });
        }
    }
}
