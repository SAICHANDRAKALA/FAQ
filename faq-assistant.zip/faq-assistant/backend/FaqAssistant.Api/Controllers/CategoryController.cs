using System;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.Model.Category;
using FaqAssistant.Model.Faq;
using System.Collections.Generic;

namespace FaqAssistant.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class CategoriesController : ControllerBase
    {
        private readonly ICategoryManager _categoryManager;

        public CategoriesController(ICategoryManager categoryManager)
        {
            _categoryManager = categoryManager;
        }

        public class ApiResponse<T>
        {
            public int Code { get; set; }
            public bool Success { get; set; }
            public IEnumerable<string> Messages { get; set; } = Array.Empty<string>();
            public T? Data { get; set; }

            public static ApiResponse<T> SuccessResponse(T? data, string message, int code = 200) =>
                new() { Code = code, Success = true, Messages = new[] { message }, Data = data };

            public static ApiResponse<T> FailureResponse(string message, int code = 400) =>
                new() { Code = code, Success = false, Messages = new[] { message }, Data = default };
        }

        private IActionResult BuildActionResult<T>(ApiResponse<T> res) => StatusCode(res.Code, res);

        [HttpPost]
        public IActionResult Create([FromBody] CategoryCreateDto dto)
        {
            try
            {
                var id = _categoryManager.CreateCategory(dto);
                return BuildActionResult(ApiResponse<object>.SuccessResponse(new { id }, "Category created successfully.", (int)HttpStatusCode.Created));
            }
            catch (Exception)
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
        }

        [HttpGet]
        public IActionResult Get([FromQuery] CategorySearchParamsDto search)
        {
            try
            {
                var categoriesPaged = _categoryManager.GetAllCategories(search) ?? new PagedResult<Category>();
                if (categoriesPaged.Items.Count > 0)
                    return BuildActionResult(ApiResponse<PagedResult<Category>>.SuccessResponse(categoriesPaged, "Categories fetched successfully.", (int)HttpStatusCode.OK));

                return BuildActionResult(ApiResponse<PagedResult<Category>>.SuccessResponse(categoriesPaged, "No categories found.", (int)HttpStatusCode.NoContent));
            }
            catch
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
        }

        [HttpGet("{id:long}")]
        public IActionResult GetById(long id)
        {
            try
            {
                var category = _categoryManager.GetCategoryById(id);
                if (category == null)
                    return BuildActionResult(ApiResponse<object>.FailureResponse("Category not found.", (int)HttpStatusCode.NotFound));

                return BuildActionResult(ApiResponse<Category>.SuccessResponse(category, "Category fetched successfully.", (int)HttpStatusCode.OK));
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex);
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
        }

        [HttpPut("{id:long}")]
        public IActionResult Update(long id, [FromBody] CategoryUpdateDto dto)
        {
            try
            {
                var success = _categoryManager.UpdateCategory(id, dto);
                if (success)
                    return BuildActionResult(ApiResponse<object>.SuccessResponse(null, "Category updated successfully.", (int)HttpStatusCode.OK));

                return BuildActionResult(ApiResponse<object>.FailureResponse("Category not found.", (int)HttpStatusCode.NotFound));
            }
            catch
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
        }

        [HttpDelete("{id:long}")]
        public IActionResult Delete(long id, [FromQuery] long deletedBy = 0)
        {
            try
            {
                var success = _categoryManager.DeleteCategory(id, deletedBy);
                if (success)
                    return BuildActionResult(ApiResponse<object>.SuccessResponse(null, "Category deleted successfully.", (int)HttpStatusCode.OK));

                return BuildActionResult(ApiResponse<object>.FailureResponse("Category not found.", (int)HttpStatusCode.NotFound));
            }
            catch
            {
                return BuildActionResult(ApiResponse<object>.FailureResponse("An unexpected error occurred. Please contact the technical team.", (int)HttpStatusCode.InternalServerError));
            }
        }
    }
}
