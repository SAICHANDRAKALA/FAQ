using System;
using System.Diagnostics;
using System.Net;
using Microsoft.AspNetCore.Mvc;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.Model.User;
using FaqAssistant.Model.Faq;
using Microsoft.AspNetCore.Authorization;

namespace FaqAssistant.Api.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    [Authorize]
    public class UsersController : ControllerBase
    {
        private readonly IUserManager _manager;
        public UsersController(IUserManager manager)
        {
            _manager = manager;
        }

        public class ApiResponse<T>
        {
            public int Code { get; set; }
            public bool Success { get; set; }
            public IEnumerable<string> Messages { get; set; } = Array.Empty<string>();
            public T? Data { get; set; }
        }

        private IActionResult BuildActionResult<T>(ApiResponse<T> res) => StatusCode(res.Code, res);

        [HttpPost]
        [ResponseCache(NoStore = true)]
        public IActionResult Create([FromBody] UserCreateDto dto)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                // rely on [ApiController] model validation and InvalidModelStateResponseFactory
                var id = _manager.CreateUser(dto);
                if (id > 0)
                {
                    return BuildActionResult(new ApiResponse<object>
                    {
                        Code = (int)HttpStatusCode.Created,
                        Success = true,
                        Messages = new[] { "User created successfully." },
                        Data = new { id }
                    });
                }

                return BuildActionResult(new ApiResponse<object>
                {
                    Code = (int)HttpStatusCode.InternalServerError,
                    Success = false,
                    Messages = new[] { "Failed to create user." },
                    Data = null
                });
            }
            catch (Exception)
            {
                // TODO: log exception
                return BuildActionResult(new ApiResponse<object>
                {
                    Code = (int)HttpStatusCode.InternalServerError,
                    Success = false,
                    Messages = new[] { "An unexpected error occurred. Please contact the technical team." },
                    Data = null
                });
            }
            finally { timer.Stop(); }
        }

        [HttpGet("{id:long}")]
        [ResponseCache(NoStore = true)]
        public IActionResult Get([FromRoute] long id)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                if (id <= 0)
                    return BuildActionResult(new ApiResponse<object>
                    {
                        Code = (int)HttpStatusCode.BadRequest,
                        Success = false,
                        Messages = new[] { "Invalid request. Id must be greater than zero." },
                        Data = null
                    });

                var user = _manager.GetUserById(id);
                if (user != null)
                {
                    return BuildActionResult(new ApiResponse<User>
                    {
                        Code = (int)HttpStatusCode.OK,
                        Success = true,
                        Messages = new[] { "User fetched successfully." },
                        Data = user
                    });
                }

                return BuildActionResult(new ApiResponse<object>
                {
                    Code = (int)HttpStatusCode.NotFound,
                    Success = false,
                    Messages = new[] { "User not found." },
                    Data = null
                });
            }
            catch (Exception)
            {
                return BuildActionResult(new ApiResponse<object>
                {
                    Code = (int)HttpStatusCode.InternalServerError,
                    Success = false,
                    Messages = new[] { "An unexpected error occurred. Please contact the technical team." },
                    Data = null
                });
            }
            finally { timer.Stop(); }
        }

        [HttpPut("{id:long}")]
        [ResponseCache(NoStore = true)]
        public IActionResult Update([FromRoute] long id, [FromBody] UserUpdateDto dto)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                // rely on DTO annotations and InvalidModelStateResponseFactory
                var ok = _manager.UpdateUser(id, dto);
                if (ok)
                {
                    return BuildActionResult(new ApiResponse<object>
                    {
                        Code = (int)HttpStatusCode.OK,
                        Success = true,
                        Messages = new[] { "User updated successfully." },
                        Data = null
                    });
                }

                return BuildActionResult(new ApiResponse<object>
                {
                    Code = (int)HttpStatusCode.NotFound,
                    Success = false,
                    Messages = new[] { "No user found to update." },
                    Data = null
                });
            }
            catch (Exception)
            {
                return BuildActionResult(new ApiResponse<object>
                {
                    Code = (int)HttpStatusCode.InternalServerError,
                    Success = false,
                    Messages = new[] { "An unexpected error occurred. Please contact the technical team." },
                    Data = null
                });
            }
            finally { timer.Stop(); }
        }

        [HttpDelete("{id:long}")]
        [ResponseCache(NoStore = true)]
        public IActionResult Delete([FromRoute] long id, [FromQuery] long updatedBy)
        {
            var timer = Stopwatch.StartNew();
            try
            {
                var ok = _manager.DeleteUser(id, updatedBy);
                if (ok)
                {
                    return BuildActionResult(new ApiResponse<object>
                    {
                        Code = (int)HttpStatusCode.OK,
                        Success = true,
                        Messages = new[] { "User deleted successfully." },
                        Data = null
                    });
                }

                return BuildActionResult(new ApiResponse<object>
                {
                    Code = (int)HttpStatusCode.NotFound,
                    Success = false,
                    Messages = new[] { "No user found to delete." },
                    Data = null
                });
            }
            catch (Exception)
            {
                return BuildActionResult(new ApiResponse<object>
                {
                    Code = (int)HttpStatusCode.InternalServerError,
                    Success = false,
                    Messages = new[] { "An unexpected error occurred. Please contact the technical team." },
                    Data = null
                });
            }
            finally { timer.Stop(); }
        }
    }
}
