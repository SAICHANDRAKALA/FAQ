// wwwroot/swagger-ui/custom-swagger.js
(function () {
  console.info('custom-swagger.js: loaded');

  function ready(fn) {
    if (document.readyState !== 'loading') fn(); else document.addEventListener('DOMContentLoaded', fn);
  }

  ready(function () {
    // Wait until opblocks render
    function waitForOpBlocks(cb, attempts = 0) {
      var opblocks = document.querySelectorAll('.opblock');
      if (opblocks && opblocks.length && attempts < 50) return cb(opblocks);
      if (attempts >= 50) {
        console.warn('custom-swagger: opblocks not found after 50 attempts');
        return;
      }
      setTimeout(function () { waitForOpBlocks(cb, attempts + 1); }, 100);
    }

    waitForOpBlocks(function (opblocks) {
      console.info('custom-swagger: found opblocks count=', opblocks.length);

      // Accept multiple target path formats; do case-insensitive match
      var targetPaths = [
        '/api/faq/suggest',
        '/api/Faq/suggest',
        '/Faq/suggest',
        '/faq/suggest',
        '/api/faq/Suggest',
        '/api/Faq/Suggest'
      ].map(p => p.toLowerCase());

      var targetOp = null;
      opblocks.forEach(function (op) {
        var pathEl = op.querySelector('.opblock-summary-path');
        if (!pathEl) return;
        var p = pathEl.textContent.trim();
        var pl = p.toLowerCase();
        // find any that equals or endsWith any target path (case-insensitive)
        for (var i = 0; i < targetPaths.length; i++) {
          var tp = targetPaths[i];
          if (pl === tp || pl.endsWith(tp)) {
            targetOp = op;
            break;
          }
        }
      });

      if (!targetOp) {
        console.warn('custom-swagger: could not find opblock for any of', targetPaths);
        // Also print available paths to help debugging
        var paths = Array.from(opblocks).map(function(op){
          var pe = op.querySelector('.opblock-summary-path');
          return pe ? pe.textContent.trim() : '[no-path]';
        });
        console.info('custom-swagger: available op paths:', paths);
        return;
      }

      console.info('custom-swagger: target op found');

      // Avoid adding multiple buttons if script runs twice
      if (targetOp.__customSuggestButtonAdded) {
        console.info('custom-swagger: button already added');
        return;
      }
      targetOp.__customSuggestButtonAdded = true;

      var btn = document.createElement('button');
      btn.type = 'button';
      btn.innerText = 'Suggest answer';
      btn.className = 'btn try-out__btn';
      btn.style.marginLeft = '8px';

      // Try a few places to append the button
      var controls = targetOp.querySelector('.opblock-summary-controls');
      if (controls) {
        controls.appendChild(btn);
      } else {
        var summary = targetOp.querySelector('.opblock-summary');
        if (summary) summary.appendChild(btn); else targetOp.appendChild(btn);
      }

      // Handler: expand opblock, click Try it out, prefill body if empty, then Execute
      btn.addEventListener('click', function () {
        try {
          var summary = targetOp.querySelector('.opblock-summary');
          if (summary && !targetOp.classList.contains('is-open')) {
            summary.click();
          }

          setTimeout(function () {
            // Find try out button: some versions use 'try-out__btn' and may be inside this opblock
            var tryOutBtn = targetOp.querySelector('button.try-out__btn, button[aria-label="Try it out"], button[title="Try it out"]');
            var executeBtn = targetOp.querySelector('button.execute, button[aria-label="Execute"], button[title="Execute"]');

            // If tryOutBtn exists and currently is "Try it out", click it
            if (tryOutBtn && tryOutBtn.textContent && tryOutBtn.textContent.toLowerCase().includes('try it out')) {
              tryOutBtn.click();
            }

            setTimeout(function () {
              // Attempt to find body textarea/editor
              var textarea = targetOp.querySelector('.body-param textarea') 
                          || targetOp.querySelector('.body-param .microlight') 
                          || targetOp.querySelector('textarea.swagger-ui-tryout-body');

              if (textarea) {
                var current = (textarea.value || textarea.textContent || '').trim();
                if (!current) {
                  var sample = {
                    question: "How do I update my billing information?",
                    maxTokens: 200,
                    temperature: 0.2
                  };
                  if (textarea.tagName && textarea.tagName.toLowerCase() === 'textarea') {
                    textarea.value = JSON.stringify(sample, null, 2);
                    textarea.dispatchEvent(new Event('input', { bubbles: true }));
                  } else {
                    textarea.textContent = JSON.stringify(sample, null, 2);
                    var ev = new Event('input', { bubbles: true });
                    textarea.dispatchEvent(ev);
                  }
                }
              } else {
                console.warn('custom-swagger: no body textarea found for operation (it may not accept body)');
              }

              // Click Execute
              if (executeBtn) {
                executeBtn.click();
              } else {
                // fallback: search for a button with text 'execute'
                var execFallback = Array.from(targetOp.querySelectorAll('button')).find(b => b.textContent && b.textContent.trim().toLowerCase() === 'execute');
                if (execFallback) execFallback.click(); else console.warn('custom-swagger: execute button not found');
              }
            }, 300);

          }, 150);
        } catch (err) {
          console.error('custom-swagger Suggest button error', err);
        }
      });

      console.info('custom-swagger: Suggest button injected');
    });
  });
})();
