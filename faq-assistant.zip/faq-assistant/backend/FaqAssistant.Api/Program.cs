using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;

// Program.cs
var builder = WebApplication.CreateBuilder(args);

// Use your Startup to register services
var startup = new Startup(builder.Configuration);
startup.ConfigureServices(builder.Services);

var app = builder.Build();

// Use Startup to configure the middleware pipeline
startup.Configure(app, app.Environment);

app.Run();
