// Startup.cs
using System;
using System.Linq;
using System.Text;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.IdentityModel.Tokens;

using FaqAssistant.Business.Core;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.DataAccess.Core;
using FaqAssistant.DataAccess.Core.Interface;
using FaqAssistant.Model.User;
// using FaqAssistant.Api.Configuration; // JwtSettings class

public class Startup
{
    public IConfiguration Configuration { get; }
    public Startup(IConfiguration configuration)
    {
        Configuration = configuration;
    }

    public void ConfigureServices(IServiceCollection services)
    {
        services.AddControllers();

        // Api behavior (model validation) - requires Microsoft.AspNetCore.Mvc
        services.Configure<ApiBehaviorOptions>(options =>
        {
            options.InvalidModelStateResponseFactory = context =>
            {
                var errors = context.ModelState.Values
                    .SelectMany(v => v.Errors)
                    .Select(e =>
                        string.IsNullOrWhiteSpace(e.ErrorMessage)
                            ? e.Exception?.Message
                            : e.ErrorMessage
                    )
                    .Where(m => !string.IsNullOrWhiteSpace(m))
                    .ToArray();

                var response = new
                {
                    code = StatusCodes.Status400BadRequest,
                    success = false,
                    messages = errors.Length > 0 ? errors : new[] { "Invalid request." },
                    data = (object)null
                };

                return new BadRequestObjectResult(response);
            };
        });

        services.AddEndpointsApiExplorer();
        services.AddSwaggerGen();

        // Register MySQLHelper with connection string from config
        services.AddSingleton<MySQLHelper>(provider =>
            new MySQLHelper(Configuration.GetConnectionString("DefaultConnection")));

        // Business & data registrations
        services.AddScoped<IFaqManager, FaqManager>();
        services.AddScoped<IFaqRepository, FaqRepository>();
        services.AddScoped<ICategoryManager, CategoryManager>();
        services.AddScoped<ICategoryRepository, CategoryRepository>();
        services.AddScoped<ITagManager, TagManager>();
        services.AddScoped<ITagRepository, TagRepository>();
        services.AddScoped<IUserManager, UserManager>();
        services.AddScoped<IUserRepository, UserRepository>();
        services.AddScoped<IAiService, GroqAiService>();
        services.AddScoped<IAuthService, AuthService>();

        // Password hasher
        services.AddScoped<IPasswordHasher<User>, PasswordHasher<User>>();

        // Bind JWT settings
        services.Configure<JwtSettings>(Configuration.GetSection("Jwt"));
        var jwtSettings = Configuration.GetSection("Jwt").Get<JwtSettings>() ?? new JwtSettings();
        var key = Encoding.UTF8.GetBytes(jwtSettings.Secret);

        // Authentication
        services.AddAuthentication(options =>
        {
            options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
            options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
        })
        .AddJwtBearer(options =>
        {
            // In production set RequireHttpsMetadata = true
            options.RequireHttpsMetadata = false;
            options.SaveToken = true;
            options.TokenValidationParameters = new TokenValidationParameters
            {
                ValidateIssuer = true,
                ValidIssuer = jwtSettings.Issuer,
                ValidateAudience = true,
                ValidAudience = jwtSettings.Audience,
                ValidateIssuerSigningKey = true,
                IssuerSigningKey = new SymmetricSecurityKey(key),
                ValidateLifetime = true,
                ClockSkew = TimeSpan.FromSeconds(30)
            };
        });

        // Http client for AI service (existing)
        services.AddHttpClient<IAiService, GroqAiService>();
    }

    public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
    {
        if (env.IsDevelopment())
        {
            app.UseSwagger();
            app.UseSwaggerUI(c =>
            {
                c.SwaggerEndpoint("/swagger/v1/swagger.json", "FAQ API V1");
                c.InjectJavascript("/swagger-ui/custom-swagger.js");
            });
        }

        app.UseHttpsRedirection();
        app.UseRouting();

        // enable authentication/authorization middleware
        app.UseAuthentication();
        app.UseAuthorization();

        app.UseStaticFiles();
        app.UseEndpoints(endpoints =>
        {
            endpoints.MapControllers();
        });
    }
}
