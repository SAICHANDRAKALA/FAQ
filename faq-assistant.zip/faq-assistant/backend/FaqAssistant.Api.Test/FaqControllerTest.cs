using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;
using FaqAssistant.Api.Controllers;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.Api.Test
{
    public class FaqControllerTest
    {
        private readonly Mock<IFaqManager> _mockManager;
        private readonly FaqController _controller;

        public FaqControllerTest()
        {
            _mockManager = new Mock<IFaqManager>();
            _controller = new FaqController(_mockManager.Object);
        }

        [Fact]
        public void GetAll_ReturnsOk_WhenFaqsExist()
        {
            var search = new FaqSearchParamsDto();
            var paged = new PagedResult<Faq>
            {
                Items = new List<Faq> { new Faq { Id = 1, Question = "Q1" } }
            };
            _mockManager.Setup(m => m.GetAllFaqs(search)).Returns(paged);

            var result = _controller.GetAll(search) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void GetAll_ReturnsOk_WhenNoFaqs()
        {
            var search = new FaqSearchParamsDto();
            var paged = new PagedResult<Faq> { Items = new List<Faq>() };
            _mockManager.Setup(m => m.GetAllFaqs(search)).Returns(paged);

            var result = _controller.GetAll(search) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Get_ReturnsOk_WhenFaqExists()
        {
            var faq = new Faq { Id = 1, Question = "Q1" };
            _mockManager.Setup(m => m.GetFaqById(1)).Returns(faq);

            var result = _controller.Get(1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Get_ReturnsNotFound_WhenFaqDoesNotExist()
        {
            _mockManager.Setup(m => m.GetFaqById(1)).Returns((Faq)null);

            var result = _controller.Get(1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public void Create_ReturnsCreated_WhenFaqIsCreated()
        {
            var dto = new FaqCreateDto { Question = "Q1", CategoryId = 1, CreatedBy = 1 };
            _mockManager.Setup(m => m.CreateFaq(dto)).Returns(1);

            var result = _controller.Create(dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Update_ReturnsOk_WhenFaqUpdated()
        {
            var dto = new FaqUpdateDto { Question = "Q1", UpdatedBy = 1 };
            _mockManager.Setup(m => m.UpdateFaq(1, dto)).Returns(true);

            var result = _controller.Update(1, dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Update_ReturnsNotFound_WhenFaqNotFound()
        {
            var dto = new FaqUpdateDto { Question = "Q1", UpdatedBy = 1 };
            _mockManager.Setup(m => m.UpdateFaq(1, dto)).Returns(false);

            var result = _controller.Update(1, dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public void Delete_ReturnsOk_WhenFaqDeleted()
        {
            _mockManager.Setup(m => m.DeleteFaq(1, 1)).Returns(true);

            var result = _controller.Delete(1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Delete_ReturnsNotFound_WhenFaqNotFound()
        {
            _mockManager.Setup(m => m.DeleteFaq(1, 1)).Returns(false);

            var result = _controller.Delete(1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public void AddTags_ReturnsOk_WhenTagsAdded()
        {
            var tagIds = new List<long> { 1, 2 };
            _mockManager.Setup(m => m.AddTags(1, tagIds, 1)).Returns(true);

            var result = _controller.AddTags(1, tagIds, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void AddTags_ReturnsInternalServerError_WhenTagsNotAdded()
        {
            var tagIds = new List<long> { 1, 2 };
            _mockManager.Setup(m => m.AddTags(1, tagIds, 1)).Returns(false);

            var result = _controller.AddTags(1, tagIds, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
        }

        [Fact]
        public void RemoveTag_ReturnsOk_WhenTagRemoved()
        {
            _mockManager.Setup(m => m.RemoveTag(1, 1, 1)).Returns(true);

            var result = _controller.RemoveTag(1, 1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void RemoveTag_ReturnsNotFound_WhenTagNotFound()
        {
            _mockManager.Setup(m => m.RemoveTag(1, 1, 1)).Returns(false);

            var result = _controller.RemoveTag(1, 1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public async Task SuggestAnswer_ReturnsOk_WhenAnswerGenerated()
        {
            var req = new AiSuggestionRequestDto { Question = "Q1", MaxTokens = 100, Temperature = 0.7f };
            _mockManager.Setup(m => m.GetAiSuggestedAnswerAsync(req.Question, req.MaxTokens, req.Temperature.Value))
                .ReturnsAsync("Suggested answer");

            var result = await _controller.SuggestAnswer(req) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }
    }
}