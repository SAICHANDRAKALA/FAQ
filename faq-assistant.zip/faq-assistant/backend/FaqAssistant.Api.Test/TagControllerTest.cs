using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net;
using FaqAssistant.Api.Controllers;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.Model.Tag;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.Api.Test
{
    public class TagControllerTest
    {
        private readonly Mock<ITagManager> _mockManager;
        private readonly TagsController _controller;

        public TagControllerTest()
        {
            _mockManager = new Mock<ITagManager>();
            _controller = new TagsController(_mockManager.Object);
        }

        [Fact]
        public void GetAll_ReturnsOk_WhenTagsExist()
        {
            var search = new TagSearchParamsDto();
            var paged = new PagedResult<Tag>
            {
                Items = new List<Tag> { new Tag { Id = 1, Name = "Tag1" } }
            };
            _mockManager.Setup(m => m.GetAllTags(It.IsAny<TagSearchParamsDto>())).Returns(paged);

            var result = _controller.GetAll(1, 50, null) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void GetAll_ReturnsNoContent_WhenNoTags()
        {
            var search = new TagSearchParamsDto();
            var paged = new PagedResult<Tag> { Items = new List<Tag>() };
            _mockManager.Setup(m => m.GetAllTags(It.IsAny<TagSearchParamsDto>())).Returns(paged);

            var result = _controller.GetAll(1, 50, null) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NoContent, result.StatusCode);
        }

        [Fact]
        public void Get_ReturnsOk_WhenTagExists()
        {
            var tag = new Tag { Id = 1, Name = "Tag1" };
            _mockManager.Setup(m => m.GetTagById(1)).Returns(tag);

            var result = _controller.Get(1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Get_ReturnsNotFound_WhenTagDoesNotExist()
        {
            _mockManager.Setup(m => m.GetTagById(1)).Returns((Tag)null);

            var result = _controller.Get(1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public void Create_ReturnsCreated_WhenTagIsCreated()
        {
            var dto = new TagCreateDto { Name = "Tag1", CreatedBy = 1 };
            _mockManager.Setup(m => m.CreateTag(dto)).Returns(1);

            var result = _controller.Create(dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Create_ReturnsInternalServerError_WhenTagNotCreated()
        {
            var dto = new TagCreateDto { Name = "Tag1", CreatedBy = 1 };
            _mockManager.Setup(m => m.CreateTag(dto)).Returns(0);

            var result = _controller.Create(dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
        }

        [Fact]
        public void Update_ReturnsOk_WhenTagUpdated()
        {
            var dto = new TagUpdateDto { Name = "Tag1", UpdatedBy = 1 };
            _mockManager.Setup(m => m.UpdateTag(1, dto)).Returns(true);

            var result = _controller.Update(1, dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Update_ReturnsNotFound_WhenTagNotFound()
        {
            var dto = new TagUpdateDto { Name = "Tag1", UpdatedBy = 1 };
            _mockManager.Setup(m => m.UpdateTag(1, dto)).Returns(false);

            var result = _controller.Update(1, dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public void Delete_ReturnsOk_WhenTagDeleted()
        {
            _mockManager.Setup(m => m.DeleteTag(1, 1)).Returns(true);

            var result = _controller.Delete(1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Delete_ReturnsNotFound_WhenTagNotFound()
        {
            _mockManager.Setup(m => m.DeleteTag(1, 1)).Returns(false);

            var result = _controller.Delete(1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }
    }
}