using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc;
using System.Net;
using FaqAssistant.Api.Controllers;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.Model.User;

namespace FaqAssistant.Api.Test
{
    public class UserControllerTest
    {
        private readonly Mock<IUserManager> _mockManager;
        private readonly UsersController _controller;

        public UserControllerTest()
        {
            _mockManager = new Mock<IUserManager>();
            _controller = new UsersController(_mockManager.Object);
        }

        [Fact]
        public void Create_ReturnsCreated_WhenUserIsCreated()
        {
            var dto = new UserCreateDto { UserName = "test", CreatedBy = 1 };
            _mockManager.Setup(m => m.CreateUser(dto)).Returns(1);

            var result = _controller.Create(dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Create_ReturnsInternalServerError_WhenUserNotCreated()
        {
            var dto = new UserCreateDto { UserName = "test", CreatedBy = 1 };
            _mockManager.Setup(m => m.CreateUser(dto)).Returns(0);

            var result = _controller.Create(dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.InternalServerError, result.StatusCode);
        }

        [Fact]
        public void Get_ReturnsOk_WhenUserExists()
        {
            var user = new User { Id = 1, UserName = "test" };
            _mockManager.Setup(m => m.GetUserById(1)).Returns(user);

            var result = _controller.Get(1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Get_ReturnsNotFound_WhenUserDoesNotExist()
        {
            _mockManager.Setup(m => m.GetUserById(1)).Returns((User)null);

            var result = _controller.Get(1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public void Get_ReturnsBadRequest_WhenIdIsInvalid()
        {
            var result = _controller.Get(0) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.BadRequest, result.StatusCode);
        }

        [Fact]
        public void Update_ReturnsOk_WhenUserUpdated()
        {
            var dto = new UserUpdateDto { UserName = "updated", UpdatedBy = 1 };
            _mockManager.Setup(m => m.UpdateUser(1, dto)).Returns(true);

            var result = _controller.Update(1, dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Update_ReturnsNotFound_WhenUserNotFound()
        {
            var dto = new UserUpdateDto { UserName = "updated", UpdatedBy = 1 };
            _mockManager.Setup(m => m.UpdateUser(1, dto)).Returns(false);

            var result = _controller.Update(1, dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public void Delete_ReturnsOk_WhenUserDeleted()
        {
            _mockManager.Setup(m => m.DeleteUser(1, 1)).Returns(true);

            var result = _controller.Delete(1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Delete_ReturnsNotFound_WhenUserNotFound()
        {
            _mockManager.Setup(m => m.DeleteUser(1, 1)).Returns(false);

            var result = _controller.Delete(1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }
    }
}