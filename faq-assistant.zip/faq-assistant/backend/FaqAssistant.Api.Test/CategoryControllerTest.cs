using Xunit;
using Moq;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Net;
using FaqAssistant.Api.Controllers;
using FaqAssistant.Business.Core.Interface;
using FaqAssistant.Model.Category;
using FaqAssistant.Model.Faq;

namespace FaqAssistant.Api.Test
{
    public class CategoryControllerTest
    {
        private readonly Mock<ICategoryManager> _mockManager;
        private readonly CategoriesController _controller;

        public CategoryControllerTest()
        {
            _mockManager = new Mock<ICategoryManager>();
            _controller = new CategoriesController(_mockManager.Object);
        }

        [Fact]
        public void Create_ReturnsCreated_WhenCategoryIsCreated()
        {
            var dto = new CategoryCreateDto { Name = "Test", CreatedBy = 1 };
            _mockManager.Setup(m => m.CreateCategory(dto)).Returns(1);

            var result = _controller.Create(dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.Created, result.StatusCode);
        }

        [Fact]
        public void Get_ReturnsOk_WhenCategoriesExist()
        {
            var search = new CategorySearchParamsDto();
            var paged = new PagedResult<Category>
            {
                Items = new List<Category> { new Category { Id = 1, Name = "Test" } }
            };
            _mockManager.Setup(m => m.GetAllCategories(search)).Returns(paged);

            var result = _controller.Get(search) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Get_ReturnsNoContent_WhenNoCategories()
        {
            var search = new CategorySearchParamsDto();
            var paged = new PagedResult<Category> { Items = new List<Category>() };
            _mockManager.Setup(m => m.GetAllCategories(search)).Returns(paged);

            var result = _controller.Get(search) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NoContent, result.StatusCode);
        }

        [Fact]
        public void GetById_ReturnsOk_WhenCategoryExists()
        {
            var cat = new Category { Id = 1, Name = "Test" };
            _mockManager.Setup(m => m.GetCategoryById(1)).Returns(cat);

            var result = _controller.GetById(1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void GetById_ReturnsNotFound_WhenCategoryDoesNotExist()
        {
            _mockManager.Setup(m => m.GetCategoryById(1)).Returns((Category)null);

            var result = _controller.GetById(1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public void Update_ReturnsOk_WhenCategoryUpdated()
        {
            var dto = new CategoryUpdateDto { Name = "Updated", UpdatedBy = 1 };
            _mockManager.Setup(m => m.UpdateCategory(1, dto)).Returns(true);

            var result = _controller.Update(1, dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Update_ReturnsNotFound_WhenCategoryNotFound()
        {
            var dto = new CategoryUpdateDto { Name = "Updated", UpdatedBy = 1 };
            _mockManager.Setup(m => m.UpdateCategory(1, dto)).Returns(false);

            var result = _controller.Update(1, dto) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }

        [Fact]
        public void Delete_ReturnsOk_WhenCategoryDeleted()
        {
            _mockManager.Setup(m => m.DeleteCategory(1, 1)).Returns(true);

            var result = _controller.Delete(1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.OK, result.StatusCode);
        }

        [Fact]
        public void Delete_ReturnsNotFound_WhenCategoryNotFound()
        {
            _mockManager.Setup(m => m.DeleteCategory(1, 1)).Returns(false);

            var result = _controller.Delete(1, 1) as ObjectResult;

            Assert.NotNull(result);
            Assert.Equal((int)HttpStatusCode.NotFound, result.StatusCode);
        }
    }
}